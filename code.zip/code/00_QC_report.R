# =====================================================================
# 00_QC_report.R
# Run after 01–03 to consolidate QC and produce the QC artifacts.
# =====================================================================

source("R/setup.R")

master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE)
clin      <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                      show_col_types = FALSE)
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)
genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
prot_anno <- readRDS(file.path(PROC_DIR, "metaprot_annotation.rds"))
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
metab_feat<- read_csv(file.path(PROC_DIR, "metab_features.csv"),
                      show_col_types = FALSE)

# --- 1. Master mapping (already saved by 01) -------------------------
file.copy(file.path(PROC_DIR, "sample_master_mapping.csv"),
          file.path(TABLE_DIR, "sample_mapping_master.csv"),
          overwrite = TRUE)

# --- 2. Per-sample omics intersection -------------------------------
omics_avail <- master %>%
  transmute(
    company_id, time_window,
    has_clinical    = !is.na(cr_umol_L) | !is.na(cysC_mg_L),
    has_metagenome  = company_id %in% unique(genus$company_id),
    has_metaprot    = company_id %in% unique(metaprot$company_id),
    has_metabolome  = company_id %in% unique(metab$company_id),
    has_metaprot_QCpass = company_id %in% (prot_qc %>%
      filter(qc_status != "fail") %>% pull(company_id))
  )
save_fig_data(omics_avail, "omics_sample_intersection.csv")

# --- 3. Clinical missingness ----------------------------------------
clin_miss <- clin %>%
  select(-company_id, -time_window) %>%
  summarise(across(everything(),
                   list(n_total = ~ length(.),
                        n_miss  = ~ sum(is.na(.)),
                        pct_miss = ~ round(mean(is.na(.)) * 100, 1)))) %>%
  pivot_longer(everything(),
               names_to = c("variable", "stat"),
               names_pattern = "(.*)_(n_total|n_miss|pct_miss)") %>%
  pivot_wider(names_from = stat, values_from = value)
save_fig_data(clin_miss, "clinical_missingness.csv")

# --- 4. Excluded samples report -------------------------------------
excluded <- bind_rows(
  prot_qc %>% filter(qc_status == "fail") %>%
    transmute(company_id, prot_name, reason = "metaproteome <1500 proteins",
              detail = paste0("protein_n=", protein_n)),
  master %>% filter(!is.na(clin_anomaly_flag)) %>%
    transmute(company_id, prot_name = NA_character_,
              reason = "clinical anomaly",
              detail = clin_anomaly_flag)
)
save_fig_data(excluded, "excluded_samples.csv")

# --- 5. Protein depth summary ---------------------------------------
prot_depth <- prot_qc %>%
  inner_join(master %>% select(company_id, time_window), by = "company_id") %>%
  group_by(time_window) %>%
  summarise(n         = n(),
            prot_med  = median(protein_n),
            prot_min  = min(protein_n),
            prot_max  = max(protein_n),
            n_pass    = sum(qc_status == "pass"),
            n_warn    = sum(qc_status == "warn"),
            n_fail    = sum(qc_status == "fail"),
            .groups = "drop")
save_fig_data(prot_depth, "protein_depth_summary.csv")

# --- 6. Metabolite coverage summary ---------------------------------
metab_n_per_sample <- metab %>%
  group_by(company_id) %>%
  summarise(n_metab_detected = n(), .groups = "drop") %>%
  inner_join(master %>% select(company_id, time_window), by = "company_id")

metab_summary <- list(
  total_features_in_file = nrow(metab_feat),
  level_1_2_3_count      = sum(metab_feat$Level %in% c("level1","level2","level3")),
  median_per_sample      = median(metab_n_per_sample$n_metab_detected)
) %>% as_tibble() %>% mutate(metric = c("total","level1to3","median_per_sample")) %>%
  rename(value = 1) %>% select(metric, value)
save_fig_data(metab_n_per_sample, "metabolite_coverage_per_sample.csv")
save_fig_data(metab_summary, "metabolite_coverage_summary.csv")

# --- 7. Trp-IS feature availability ---------------------------------
# Genera
trp_genera <- c("Bacteroides", "Alistipes", "Escherichia", "Fusobacterium")
gen_avail <- genus %>% filter(genus %in% trp_genera) %>%
  group_by(genus) %>%
  summarise(prevalence = mean(rel_abund > 0),
            mean_abund = mean(rel_abund),
            .groups = "drop") %>%
  mutate(layer = "Genus", feature = genus, .keep = "unused")

# Proteins (KO-aggregated)
target_kos <- c("K01667", "K00179", "K00180", "K01695", "K01696",
                "K00466", "K01556")
ko_to_label <- c(
  K01667 = "TnaA tryptophanase",
  K00179 = "Indolepyruvate FOR α",
  K00180 = "Indolepyruvate FOR β",
  K01695 = "Tryptophan synthase α",
  K01696 = "Tryptophan synthase β",
  K00466 = "TDO/IDO",
  K01556 = "KMO"
)
prot_for_ko <- prot_anno %>% filter(KO_id %in% target_kos) %>%
  select(protein_id, KO_id, Taxonomy_genus)
ko_avail <- prot_for_ko %>% group_by(KO_id) %>%
  summarise(n_proteins = n(),
            n_with_genus = sum(!is.na(Taxonomy_genus)),
            n_unique_genera = n_distinct(Taxonomy_genus, na.rm = TRUE),
            .groups = "drop") %>%
  mutate(layer = "Protein",
         feature = ko_to_label[KO_id])

# Metabolites
trp_metab_kw <- c(
  Tryptophan = "^L-Tryptophan$|^Tryptophan$",
  Indole     = "^Indole$",
  IS         = "Indoxyl sulph|Indoxyl sulf",
  IAA        = "Indole-3-acetic|Indoleacetic",
  Kyn        = "^L-Kynurenine$|^Kynurenine$",
  KynA       = "Kynurenic acid"
)
metab_avail <- map_dfr(names(trp_metab_kw), function(lbl) {
  hit <- metab_feat %>%
    filter(grepl(trp_metab_kw[lbl], Name, ignore.case = TRUE)) %>%
    filter(Level %in% c("level1", "level2"))
  if (nrow(hit) == 0) {
    return(tibble(feature = lbl, layer = "Metabolite",
                  detected = FALSE, level = NA_character_,
                  metabolite_id = NA_character_, name = NA_character_))
  }
  hit <- hit[1, ]
  tibble(feature = lbl, layer = "Metabolite",
         detected = TRUE, level = hit$Level,
         metabolite_id = hit$metabolite_id, name = hit$Name)
})

trp_avail <- bind_rows(
  gen_avail   %>% select(layer, feature, prevalence, mean_abund),
  ko_avail    %>% select(layer, feature, n_proteins, n_with_genus, n_unique_genera),
  metab_avail %>% select(layer, feature, detected, level, metabolite_id, name)
)
save_fig_data(trp_avail, "trp_is_feature_availability.csv")

# --- 8. Feature filtering pre/post counts --------------------------
filt_summary <- tibble(
  layer  = c("Genus", "Genus_filtered", "Protein", "Protein_filtered",
             "Metabolite_total", "Metabolite_level1to3"),
  n_features = c(
    n_distinct(genus$genus),
    {  # genus filter
       g <- genus %>% group_by(genus) %>%
         summarise(prev = mean(rel_abund > 0),
                   mean = mean(rel_abund), .groups = "drop")
       sum(g$prev >= GENUS_PREV_MIN & g$mean >= GENUS_ABUND_MIN)
    },
    n_distinct(metaprot$protein_id),
    {  # protein filter (≥20% prevalence among QC-pass samples)
       qc_pass_ids <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)
       p <- metaprot %>% filter(company_id %in% qc_pass_ids) %>%
         group_by(protein_id) %>%
         summarise(prev = n() / length(qc_pass_ids), .groups = "drop")
       sum(p$prev >= PROT_PREV_MIN)
    },
    nrow(metab_feat),
    sum(metab_feat$Level %in% c("level1","level2","level3"))
  )
)
save_fig_data(filt_summary, "feature_filtering_summary.csv")

message("\n[QC report] All QC tables written to ", TABLE_DIR)
