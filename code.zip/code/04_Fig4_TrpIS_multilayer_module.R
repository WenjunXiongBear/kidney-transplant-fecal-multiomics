# =====================================================================
# 12_Fig4_TrpIS_multilayer_module.R
# Multi-layer Trp-IS mechanism module:
#   candidate genera → protein modules → metabolites → renal indices
# =====================================================================

source("R/setup.R")



# ---------------------------------------------------------------------
# Local Nature-like visual system override (format-only; data/statistics unchanged)
# ---------------------------------------------------------------------
# Keep the analysis unchanged. This block only standardizes typography, borders,
# and a cleaner low-saturation palette across all figures.
TIME_COLORS <- setNames(c("#8A8A8A", "#4C78A8", "#72B7B2", "#F2CF5B", "#E45756"),
                        TIME_LEVELS)
RENAL_GROUP_COLORS <- c("Low eGFR" = "#E45756",
                        "Mid eGFR" = "#F2CF5B",
                        "High eGFR" = "#4C78A8")
LAYER_COLORS <- c("Genus" = "#4C78A8",
                  "Protein" = "#72B7B2",
                  "Metabolite" = "#F2CF5B",
                  "Renal" = "#E45756",
                  "Integrated" = "#B279A2",
                  "Score" = "#B279A2")
HEATMAP_LOW  <- "#4C78A8"
HEATMAP_MID  <- "#FFFFFF"
HEATMAP_HIGH <- "#E45756"
TEXT_COL <- "#222222"
AXIS_COL <- "#333333"
GRID_COL <- "#ECECEC"
BORDER_COL <- "#333333"

nature_panel <- theme(
  panel.border = element_rect(color = BORDER_COL, fill = NA, linewidth = 0.35),
  plot.title = element_text(face = "bold", color = TEXT_COL),
  axis.title = element_text(face = "bold", color = TEXT_COL),
  strip.text = element_text(face = "bold", color = TEXT_COL)
)

theme_nature_pub <- function(base_size = 7, base_family = "Helvetica") {
  base_size <- max(base_size, 8)
  theme_classic(base_size = base_size, base_family = base_family) %+replace%
    theme(
      text = element_text(color = TEXT_COL),
      plot.title = element_text(size = base_size + 1.2, face = "bold", hjust = 0, color = TEXT_COL),
      axis.title = element_text(size = base_size, face = "bold", color = TEXT_COL),
      axis.text = element_text(size = base_size - 1, color = "#333333"),
      axis.line = element_line(color = AXIS_COL, linewidth = 0.32),
      axis.ticks = element_line(color = AXIS_COL, linewidth = 0.28),
      axis.ticks.length = unit(1.5, "mm"),
      panel.border = element_rect(color = BORDER_COL, fill = NA, linewidth = 0.35),
      panel.grid.major.y = element_line(color = GRID_COL, linewidth = 0.25),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", color = TEXT_COL),
      legend.title = element_text(size = base_size - 1, face = "bold", color = TEXT_COL),
      legend.text = element_text(size = base_size - 1, color = "#333333"),
      legend.key.height = unit(3.8, "mm"),
      legend.key.width = unit(4.4, "mm"),
      plot.margin = margin(5, 5, 5, 5)
    )
}

panel_tag_theme <- theme(plot.tag = element_text(face = "bold", size = 12, color = TEXT_COL),
                         plot.tag.position = c(0.01, 0.99))



master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
clin      <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
prot_anno <- readRDS(file.path(PROC_DIR, "metaprot_annotation.rds"))
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
metab_feat<- read_csv(file.path(PROC_DIR, "metab_features.csv"),
                      show_col_types = FALSE)
score_df  <- readRDS(file.path(PROC_DIR, "TrpIS_layer_scores.rds"))

prot_pass <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)

# =====================================================================
# Helpers
# =====================================================================
spearman_test <- function(x, y) {
  ok <- complete.cases(x, y)
  if (sum(ok) < 8) return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  rs <- suppressWarnings(cor.test(x[ok], y[ok], method = "spearman",
                                  exact = FALSE))
  c(rho = unname(rs$estimate), p = rs$p.value, n = sum(ok))
}
partial_lm_tw <- function(x, y, tw) {
  ok <- complete.cases(x, y, tw)
  if (sum(ok) < 10) return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  fit <- lm(rank(y[ok]) ~ rank(x[ok]) + factor(tw[ok]))
  cc <- summary(fit)$coefficients
  if (!"rank(x[ok])" %in% rownames(cc))
    return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  t  <- cc["rank(x[ok])","t value"]; p <- cc["rank(x[ok])","Pr(>|t|)"]
  df <- summary(fit)$df[2]
  rho <- sign(t) * sqrt(t^2 / (t^2 + df))
  c(rho = rho, p = p, n = sum(ok))
}
group_stats <- function(values, groups) {
  ok <- complete.cases(values, groups)
  if (sum(ok) < 6) return(list(kw_p = NA, trend_p = NA))
  list(kw_p = suppressWarnings(kruskal.test(values[ok] ~ as.factor(groups[ok]))$p.value),
       trend_p = suppressWarnings(cor.test(values[ok],
                                           as.numeric(as.factor(groups[ok])),
                                           method = "spearman",
                                           exact = FALSE)$p.value))
}

# Safe grouped stats helper (avoids cur_data() inside summarise, which can fail with newer dplyr/vctrs)
calc_group_summary <- function(df, value_col, group_col = "eGFR_tertile") {
  full <- group_stats(df[[value_col]], df[[group_col]])
  sub  <- df %>% filter(time_window != "Pre")
  post <- group_stats(sub[[value_col]], sub[[group_col]])
  tibble(
    full_kw_p = full$kw_p,
    trend_p   = full$trend_p,
    post_kw_p = post$kw_p
  )
}

clin_lookup <- clin %>%
  select(company_id, time_window,
         Cr = cr_umol_L, CysC = cysC_mg_L, eGFR = egfr_ckdepi)

# eGFR tertile assignment
clin_tert <- clin_lookup %>% filter(!is.na(eGFR)) %>%
  mutate(eGFR_tertile = cut(eGFR,
    breaks = quantile(eGFR, probs = c(0,1/3,2/3,1), na.rm = TRUE),
    include.lowest = TRUE,
    labels = c("Low eGFR","Mid eGFR","High eGFR")))

# =====================================================================
# Fig4A : Pathway schematic
# =====================================================================
message("\n[Fig4A] Pathway schematic ...")

nodes <- tribble(
  ~node, ~layer, ~y,
  "Bacteroides","Genus",6, "Alistipes","Genus",5,
  "Escherichia","Genus",4, "Fusobacterium","Genus",3,
  "TnaA","Protein",6.5, "Indolepyruvate FOR","Protein",5.5,
  "Tryptophan synthase","Protein",4.5, "Kyn pathway","Protein",3,
  "Tryptophan","Metabolite",7, "Indole","Metabolite",6,
  "3-Indoxyl sulfate","Metabolite",5, "IAA","Metabolite",4,
  "Kynurenine","Metabolite",3, "Kynurenic acid","Metabolite",2,
  "Cr","Renal",5, "CysC","Renal",4, "eGFR","Renal",3
) %>%
  mutate(layer = factor(layer,
                        levels = c("Genus","Protein","Metabolite","Renal")),
         x = as.integer(layer))

edges_schema <- tribble(
  ~from, ~to,
  "Tryptophan","TnaA","Tryptophan","Indolepyruvate FOR",
  "Tryptophan","Tryptophan synthase","Tryptophan","Kyn pathway",
  "TnaA","Indole","Indole","3-Indoxyl sulfate",
  "Indolepyruvate FOR","IAA",
  "Kyn pathway","Kynurenine","Kynurenine","Kynurenic acid",
  "Bacteroides","TnaA","Alistipes","TnaA",
  "Escherichia","TnaA","Fusobacterium","TnaA",
  "Bacteroides","Indolepyruvate FOR",
  "3-Indoxyl sulfate","Cr","3-Indoxyl sulfate","CysC",
  "3-Indoxyl sulfate","eGFR",
  "Kynurenine","Cr","Kynurenine","eGFR"
)
edges_xy <- edges_schema %>%
  left_join(nodes %>% select(node,x,y) %>% rename(from=node,x_from=x,y_from=y),
            by = "from") %>%
  left_join(nodes %>% select(node,x,y) %>% rename(to=node,x_to=x,y_to=y),
            by = "to")

p4A <- ggplot() +
  geom_segment(data = edges_xy,
               aes(x = x_from, y = y_from, xend = x_to, yend = y_to),
               color = "#BDBDBD", linewidth = 0.3,
               arrow = arrow(length = unit(0.05,"inches"), type = "closed")) +
  geom_point(data = nodes, aes(x = x, y = y, fill = layer),
             shape = 21, color = "#333333", size = 3.5, stroke = 0.3) +
  geom_text(data = nodes, aes(x = x, y = y, label = node),
            hjust = 0.5, vjust = -1.4, size = 2.0, color = "#222222") +
  scale_fill_manual(values = c(LAYER_COLORS, Renal = "#E45756"), name = "Layer") +
  scale_x_continuous(breaks = 1:4,
                     labels = c("Candidate genera","Expressed proteins",
                                "Measured metabolites","Renal indices"),
                     limits = c(0.5, 4.5)) +
  scale_y_continuous(limits = c(1, 8)) +
  labs(x = NULL, y = NULL, title = "Trp-IS pathway schematic") +
  theme_nature_pub(7) +
  theme(panel.grid = element_blank(),
        axis.line.y = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.x = element_text(face = "bold"))

save_fig_pdf(p4A, "Fig4A_TrpIS_pathway_schematic", width = 8.0, height = 3.2)

# =====================================================================
# Fig4B : Candidate genera by eGFR group
# =====================================================================
message("\n[Fig4B] Candidate genera by eGFR group ...")

trp_genera <- c("Bacteroides","Alistipes","Escherichia","Fusobacterium")
genus_is <- genus %>% filter(genus %in% trp_genera) %>%
  inner_join(clin_tert %>% select(company_id, time_window, eGFR, eGFR_tertile),
             by = "company_id") %>%
  mutate(genus = factor(genus, levels = trp_genera))

# Stats per genus: KW + trend + post-Tx KW
genus_stats <- genus_is %>%
  group_by(genus) %>%
  group_modify(~ calc_group_summary(.x, value_col = "rel_abund")) %>%
  ungroup() %>%
  mutate(kw_q      = p.adjust(full_kw_p, method = "BH"),
         post_kw_q = p.adjust(post_kw_p, method = "BH"),
         label = sprintf("KW q=%.3f | trend p=%.3f | post p=%.3f",
                         kw_q, trend_p, post_kw_p))
save_fig_data(genus_stats, "Fig4B_candidate_genera_stats.csv")

p4B <- ggplot(genus_is,
              aes(eGFR_tertile, rel_abund * 100, fill = eGFR_tertile)) +
  geom_boxplot(outlier.shape = NA, width = 0.55, alpha = 0.7,
               linewidth = 0.3, color = "#333333") +
  geom_jitter(width = 0.18, size = 0.85, alpha = 0.65, color = "#444444") +
  geom_text(data = genus_stats,
            aes(x = -Inf, y = Inf, label = label),
            inherit.aes = FALSE,
            hjust = -0.05, vjust = 1.4, size = 2.0, color = "#444444") +
  facet_wrap(~ genus, scales = "free_y", nrow = 1) +
  scale_fill_manual(values = RENAL_GROUP_COLORS, guide = "none") +
  labs(x = NULL, y = "Relative abundance (%)",
       title = "Candidate genera by eGFR tertile") +
  theme_nature_pub(7) +
  theme(strip.text = element_text(face = "bold.italic"),
        axis.text.x = element_text(angle = 30, hjust = 1))

save_fig_pdf(p4B, "Fig4B_candidate_genera_eGFR_groups",
             width = 9.5, height = 3.0)

# =====================================================================
# Fig4C : Protein modules by eGFR group
# =====================================================================
message("\n[Fig4C] Protein modules ...")

modules_def <- list(
  TnaA            = list(kos = c("K01667"),
                          kw = "tryptophanase"),
  IndolepyrFOR    = list(kos = c("K00179","K00180"),
                          kw = "indolepyruvate"),
  TrpSynthase     = list(kos = c("K01695","K01696"),
                          kw = "tryptophan synthase"),
  KynPathway      = list(kos = c("K00466","K01556"),
                          kw = "kynurenine|kmo|kynureninase|tryptophan 2,3-dioxygenase|indoleamine")
)
prot_module_long <- map_dfr(names(modules_def), function(mod) {
  spec <- modules_def[[mod]]
  hit <- prot_anno %>%
    filter((!is.null(spec$kos) & KO_id %in% spec$kos) |
           grepl(spec$kw, ko_definition, ignore.case = TRUE)) %>%
    select(protein_id, KO_id, ko_definition, Taxonomy_genus, Taxonomy_species)
  if (nrow(hit) == 0) return(NULL)
  hit %>% mutate(module = mod)
}) %>% distinct(protein_id, module, .keep_all = TRUE)

save_fig_data(prot_module_long %>%
                rename(KO = KO_id, description = ko_definition,
                       genus = Taxonomy_genus, species = Taxonomy_species,
                       module_name = module),
              "Fig4C_protein_module_members.csv")

mod_per_sample <- metaprot %>% filter(company_id %in% prot_pass) %>%
  inner_join(prot_module_long %>% select(protein_id, module),
             by = "protein_id") %>%
  group_by(company_id, module) %>%
  summarise(abund = sum(abundance, na.rm = TRUE), .groups = "drop") %>%
  inner_join(clin_tert %>%
               select(company_id, time_window, eGFR, eGFR_tertile),
             by = "company_id") %>%
  mutate(module = factor(module, levels = names(modules_def)))

mod_stats <- mod_per_sample %>%
  group_by(module) %>%
  group_modify(~ calc_group_summary(.x, value_col = "abund")) %>%
  ungroup() %>%
  mutate(kw_q      = p.adjust(full_kw_p, method = "BH"),
         post_kw_q = p.adjust(post_kw_p, method = "BH"),
         label = sprintf("KW q=%.3f | trend p=%.3f | post p=%.3f",
                         kw_q, trend_p, post_kw_p))
save_fig_data(mod_stats, "Fig4C_protein_module_stats.csv")

p4C <- ggplot(mod_per_sample,
              aes(eGFR_tertile, log10(abund + 1e-12),
                  fill = eGFR_tertile)) +
  geom_boxplot(outlier.shape = NA, width = 0.55, alpha = 0.7,
               linewidth = 0.3, color = "#333333") +
  geom_jitter(width = 0.18, size = 0.85, alpha = 0.65, color = "#444444") +
  geom_text(data = mod_stats,
            aes(x = -Inf, y = Inf, label = label),
            inherit.aes = FALSE,
            hjust = -0.05, vjust = 1.4, size = 2.0, color = "#444444") +
  facet_wrap(~ module, scales = "free_y", nrow = 1) +
  scale_fill_manual(values = RENAL_GROUP_COLORS, guide = "none") +
  labs(x = NULL, y = expression(log[10]~"summed protein abundance"),
       title = "Trp-axis protein modules by eGFR tertile") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))

save_fig_pdf(p4C, "Fig4C_protein_modules_eGFR_groups", width = 9.5, height = 3.0)

# =====================================================================
# Fig4D : Metabolites by eGFR group
# =====================================================================
message("\n[Fig4D] Metabolites by eGFR group ...")

trp_metab_kw <- c(
  Tryptophan = "^L-Tryptophan$|^Tryptophan$",
  Indole     = "^Indole$",
  IS         = "Indoxyl sulph|Indoxyl sulf",
  IAA        = "Indole-3-acetic|Indoleacetic",
  Kynurenine = "^L-Kynurenine$|^Kynurenine$",
  KynA       = "Kynurenic acid"
)
trp_metab_ids <- map_chr(trp_metab_kw, function(p) {
  hit <- metab_feat %>%
    filter(grepl(p, Name, ignore.case = TRUE),
           Level %in% c("level1","level2"))
  if (nrow(hit) == 0) NA_character_ else hit$metabolite_id[1]
})
metab_id_df <- tibble(label = names(trp_metab_kw),
                      metabolite_id = trp_metab_ids) %>%
  filter(!is.na(metabolite_id))

metab_axis <- metab %>%
  inner_join(metab_id_df, by = "metabolite_id") %>%
  inner_join(clin_tert %>%
               select(company_id, time_window, eGFR, eGFR_tertile),
             by = "company_id") %>%
  mutate(label = factor(label, levels = names(trp_metab_kw)))

metab_stats <- metab_axis %>%
  group_by(label) %>%
  group_modify(~ calc_group_summary(.x, value_col = "value")) %>%
  ungroup() %>%
  mutate(kw_q      = p.adjust(full_kw_p, method = "BH"),
         post_kw_q = p.adjust(post_kw_p, method = "BH"),
         text = sprintf("KW q=%.3f | trend p=%.3f | post p=%.3f",
                        kw_q, trend_p, post_kw_p))
save_fig_data(metab_stats, "Fig4D_metabolite_stats.csv")

p4D <- ggplot(metab_axis,
              aes(eGFR_tertile, log10(value + 1), fill = eGFR_tertile)) +
  geom_boxplot(outlier.shape = NA, width = 0.55, alpha = 0.7,
               linewidth = 0.3, color = "#333333") +
  geom_jitter(width = 0.18, size = 0.85, alpha = 0.65, color = "#444444") +
  geom_text(data = metab_stats,
            aes(x = -Inf, y = Inf, label = text),
            inherit.aes = FALSE,
            hjust = -0.05, vjust = 1.4, size = 2.0, color = "#444444") +
  facet_wrap(~ label, scales = "free_y", nrow = 2) +
  scale_fill_manual(values = RENAL_GROUP_COLORS, guide = "none") +
  labs(x = NULL, y = expression(log[10]~"intensity"),
       title = "Trp-axis metabolites by eGFR tertile") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))

save_fig_pdf(p4D, "Fig4D_metabolites_eGFR_groups", width = 9.5, height = 4.6)

# =====================================================================
# Fig4E : Cross-layer correlation network
# =====================================================================
message("\n[Fig4E] Network ...")

# Per-sample wide table for all node features
genus_w <- genus %>% filter(genus %in% trp_genera) %>%
  pivot_wider(names_from = genus, values_from = rel_abund, values_fill = 0)
prot_w <- mod_per_sample %>%
  select(company_id, module, abund) %>%
  pivot_wider(names_from = module, values_from = abund, values_fill = 0) %>%
  rename_with(~ paste0("PROT__", .), -company_id)
metab_w <- metab_axis %>%
  select(company_id, label, value) %>%
  pivot_wider(names_from = label, values_from = value) %>%
  rename_with(~ paste0("MET__", .), -company_id)

three_layer <- master %>% select(company_id) %>%
  left_join(genus_w, by = "company_id") %>%
  left_join(prot_w,  by = "company_id") %>%
  left_join(metab_w, by = "company_id") %>%
  left_join(clin_lookup %>%
              rename(REN__Cr = Cr, REN__CysC = CysC, REN__eGFR = eGFR) %>%
              select(-time_window),
            by = "company_id") %>%
  filter(company_id %in% prot_pass)

feat_cols <- setdiff(names(three_layer), "company_id")
mat3 <- as.matrix(three_layer[, feat_cols])
mat3[!is.finite(mat3)] <- NA

# Compute pairwise Spearman ONLY for adjacent layers (per spec):
# Genus ↔ Protein, Protein ↔ Metabolite, Metabolite ↔ Renal,
# plus integrated_score ↔ Renal
layer_of <- function(name) {
  if (grepl("^PROT__", name)) "Protein"
  else if (grepl("^MET__", name)) "Metabolite"
  else if (grepl("^REN__", name)) "Renal"
  else "Genus"
}

allowed_pairs <- c("Genus|Protein","Protein|Metabolite","Metabolite|Renal")

pairs <- expand_grid(a = feat_cols, b = feat_cols) %>%
  filter(a < b) %>%
  rowwise() %>%
  mutate(la = layer_of(a), lb = layer_of(b),
         pair_layer = paste(sort(c(la, lb)), collapse = "|")) %>%
  ungroup() %>%
  filter(pair_layer %in% allowed_pairs)

edge_stats <- pmap_dfr(pairs %>% select(a, b), function(a, b) {
  x <- mat3[, a]; y <- mat3[, b]
  ok <- complete.cases(x, y)
  if (sum(ok) < 8) return(tibble(a = a, b = b, rho = NA_real_,
                                  p = NA_real_, n = sum(ok)))
  rs <- suppressWarnings(cor.test(x[ok], y[ok], method = "spearman",
                                  exact = FALSE))
  tibble(a = a, b = b, rho = unname(rs$estimate),
         p = rs$p.value, n = sum(ok))
}) %>%
  mutate(layer_a = vapply(a, layer_of, character(1)),
         layer_b = vapply(b, layer_of, character(1)),
         a_clean = sub("^(PROT__|MET__|REN__)", "", a),
         b_clean = sub("^(PROT__|MET__|REN__)", "", b))

# Add integrated score ↔ Renal edges
int_edges <- map_dfr(c("Cr","CysC","eGFR"), function(idx) {
  x <- score_df$TrpIS_integrated_score
  y <- score_df[[idx]]
  ok <- complete.cases(x, y)
  if (sum(ok) < 8) return(NULL)
  rs <- suppressWarnings(cor.test(x[ok], y[ok], method = "spearman",
                                  exact = FALSE))
  tibble(a = "INT__TrpIS_integrated", b = paste0("REN__", idx),
         rho = unname(rs$estimate), p = rs$p.value, n = sum(ok),
         layer_a = "Integrated", layer_b = "Renal",
         a_clean = "TrpIS_integrated", b_clean = idx)
})

edges_all <- bind_rows(edge_stats, int_edges) %>%
  mutate(edge_type = case_when(
    !is.na(p) & p < 0.05 & abs(rho) > 0.3       ~ "formal",
    !is.na(p) & (p < 0.10 | abs(rho) > 0.4)     ~ "exploratory",
    TRUE                                         ~ "none"))

save_fig_data(edges_all %>% select(layer_a, a_clean, layer_b, b_clean,
                                    rho, p, n, edge_type),
              "Fig4E_cross_layer_edges.csv")

network_edges <- edges_all %>% filter(edge_type %in% c("formal","exploratory"))

# Node table
node_layer <- c(
  setNames(rep("Genus",       length(trp_genera)),       trp_genera),
  setNames(rep("Protein",     length(modules_def)),
           paste0("PROT__", names(modules_def))),
  setNames(rep("Metabolite",  length(trp_metab_kw)),
           paste0("MET__",  names(trp_metab_kw))),
  setNames(rep("Renal",       3), c("REN__Cr","REN__CysC","REN__eGFR")),
  setNames("Integrated",      "INT__TrpIS_integrated")
)
node_df <- tibble(name = names(node_layer), layer = node_layer) %>%
  mutate(label = sub("^(PROT__|MET__|REN__|INT__)", "", name))

if (nrow(network_edges) > 0) {
  # Manual four-column layered layout (format-only; same edge table as above).
  node_df2 <- node_df %>%
    mutate(layer = factor(layer, levels = c("Genus", "Protein", "Metabolite", "Integrated", "Renal")),
           x = case_when(
             layer == "Genus"      ~ 1,
             layer == "Protein"    ~ 2,
             layer == "Metabolite" ~ 3,
             layer == "Integrated" ~ 3.55,
             layer == "Renal"      ~ 4,
             TRUE ~ 1
           )) %>%
    group_by(layer) %>%
    mutate(y = rev(seq_len(n())) - (n() + 1) / 2) %>%
    ungroup()

  edge_xy <- network_edges %>%
    left_join(node_df2 %>% select(name, x, y) %>% rename(a = name, x_from = x, y_from = y), by = "a") %>%
    left_join(node_df2 %>% select(name, x, y) %>% rename(b = name, x_to = x, y_to = y), by = "b") %>%
    filter(!is.na(x_from), !is.na(x_to))

  p4E <- ggplot() +
    geom_segment(data = edge_xy,
                 aes(x = x_from, y = y_from, xend = x_to, yend = y_to,
                     color = rho, linewidth = abs(rho), linetype = edge_type),
                 alpha = 0.85, lineend = "round") +
    geom_point(data = node_df2, aes(x = x, y = y, fill = layer),
               shape = 21, color = "#333333", size = 2.8, stroke = 0.25) +
    geom_text(data = node_df2, aes(x = x, y = y, label = label),
              size = 2.0, color = "#222222", nudge_y = 0.22, check_overlap = TRUE) +
    annotate("text", x = c(1, 2, 3, 4), y = max(node_df2$y, na.rm = TRUE) + 1.0,
             label = c("Genera", "Proteins", "Metabolites", "Renal"),
             size = 2.15, fontface = "bold", color = "#333333") +
    scale_fill_manual(values = c(LAYER_COLORS, Renal = "#E45756", Integrated = "#8A8A8A"), name = "Layer") +
    scale_color_gradient2(low = HEATMAP_LOW, mid = HEATMAP_MID, high = HEATMAP_HIGH,
                          midpoint = 0, limits = c(-1, 1), name = "Spearman ρ") +
    scale_linewidth(range = c(0.25, 1.25), name = expression(group("|", rho, "|"))) +
    scale_linetype_manual(values = c(formal = "solid", exploratory = "22"), name = "Edge") +
    scale_x_continuous(limits = c(0.65, 4.35), expand = c(0, 0)) +
    labs(x = NULL, y = NULL, title = "Cross-layer correlation network") +
    theme_void(base_size = 7, base_family = "Helvetica") +
    theme(plot.title = element_text(size = 8.5, face = "bold", hjust = 0),
          legend.position = "right", legend.box = "vertical",
          legend.text = element_text(size = 5.8),
          legend.title = element_text(size = 6.3),
          plot.margin = margin(4, 4, 4, 4))
} else {
  p4E <- ggplot() +
    annotate("text", x = 0, y = 0,
             label = "No cross-layer edges meeting formal/exploratory criteria.",
             size = 2.5) + theme_void()
}

save_fig_pdf(p4E, "Fig4E_TrpIS_cross_layer_network", width = 7.0, height = 4.5)

# =====================================================================
# Combined Fig 4
# =====================================================================
message("\n[Fig4] Combined ...")

fig4 <- (p4A + labs(title = NULL)) /
        (p4B + labs(title = NULL) | p4C + labs(title = NULL)) /
        (p4D + labs(title = NULL)) /
        (p4E + labs(title = NULL)) +
        plot_layout(heights = c(0.62, 1.05, 1.25, 1.05)) +
        plot_annotation(tag_levels = "A") &
        panel_tag_theme

save_fig_pdf(fig4, "Fig4_TrpIS_multilayer_module", width = 12.5, height = 10.5)

message("\nFig4 (multilayer module) complete.\n")
