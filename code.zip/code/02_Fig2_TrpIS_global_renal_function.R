# =====================================================================
# 10_Fig2_TrpIS_global_renal_function.R
# Multi-omic variation linked to renal-function gradients.
# =====================================================================

source("R/setup.R")

master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
clin      <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)
genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
prot_pass <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)

# ---------------------------------------------------------------------
# Build matrices
# ---------------------------------------------------------------------
genus_wide <- genus %>%
  pivot_wider(names_from = genus, values_from = rel_abund, values_fill = 0)
genus_mat <- as.matrix(genus_wide %>% select(-company_id))
rownames(genus_mat) <- genus_wide$company_id

prot_wide <- metaprot %>% filter(company_id %in% prot_pass) %>%
  pivot_wider(names_from = protein_id, values_from = abundance,
              values_fill = 0)
prot_mat <- as.matrix(prot_wide %>% select(-company_id))
rownames(prot_mat) <- prot_wide$company_id
prev <- colSums(prot_mat > 0) / nrow(prot_mat)
prot_core <- log2(prot_mat[, prev >= PROT_PREV_MIN, drop = FALSE] + 1)

metab_wide <- metab %>%
  pivot_wider(names_from = metabolite_id, values_from = value,
              values_fill = 0)
metab_mat <- as.matrix(metab_wide %>% select(-company_id))
rownames(metab_mat) <- metab_wide$company_id
metab_log <- log2(metab_mat + 1)

# ---------------------------------------------------------------------
# Distance + ordination + clinical
# ---------------------------------------------------------------------
clin_lookup <- clin %>%
  select(company_id, time_window,
         Cr = cr_umol_L, CysC = cysC_mg_L, eGFR = egfr_ckdepi)

run_pcoa <- function(mat, dist_method = "bray", scale_first = FALSE) {
  m <- if (scale_first) scale(mat) else mat
  d <- if (dist_method == "euclidean")
        dist(m) else vegan::vegdist(m, method = dist_method)
  pco <- ape::pcoa(d)
  scr <- as.data.frame(pco$vectors[, 1:2])
  names(scr) <- c("Axis1", "Axis2")
  scr$company_id <- rownames(mat)
  list(scores = scr, pe = pco$values$Relative_eig[1:2] * 100, dist = d)
}

genus_pco <- run_pcoa(genus_mat,  "bray")
prot_pco  <- run_pcoa(prot_core,  "bray")
metab_pco <- run_pcoa(metab_log,  "euclidean", scale_first = TRUE)

omic_dist <- list(
  "Metagenome (genus)"     = genus_pco$dist,
  "Metaproteome (core)"    = prot_pco$dist,
  "Metabolome (Level 1-3)" = metab_pco$dist
)
omic_pe <- list(
  "Metagenome (genus)"     = genus_pco$pe,
  "Metaproteome (core)"    = prot_pco$pe,
  "Metabolome (Level 1-3)" = metab_pco$pe
)
omic_scores <- bind_rows(
  genus_pco$scores %>% mutate(omic = "Metagenome (genus)"),
  prot_pco$scores  %>% mutate(omic = "Metaproteome (core)"),
  metab_pco$scores %>% mutate(omic = "Metabolome (Level 1-3)")
) %>%
  left_join(clin_lookup, by = "company_id") %>%
  mutate(omic = factor(omic, levels = c("Metagenome (genus)",
                                        "Metaproteome (core)",
                                        "Metabolome (Level 1-3)")))

# Add facet label with PE%
pe_label <- function(name) sprintf("%s\nAxis 1 (%.1f%%) | Axis 2 (%.1f%%)",
                                    name,
                                    omic_pe[[name]][1],
                                    omic_pe[[name]][2])
omic_scores <- omic_scores %>%
  mutate(facet_label = case_when(
    omic == "Metagenome (genus)"     ~ pe_label("Metagenome (genus)"),
    omic == "Metaproteome (core)"    ~ pe_label("Metaproteome (core)"),
    omic == "Metabolome (Level 1-3)" ~ pe_label("Metabolome (Level 1-3)")
  ),
  facet_label = factor(facet_label, levels = unique(facet_label)))

# =====================================================================
# Fig2A : Ordination colored by eGFR
# =====================================================================
message("\n[Fig2A] Ordination colored by eGFR ...")

p2A <- ggplot(omic_scores,
              aes(Axis1, Axis2, fill = eGFR, shape = time_window)) +
  geom_hline(yintercept = 0, color = "#EEF2F7", linewidth = 0.3) +
  geom_vline(xintercept = 0, color = "#EEF2F7", linewidth = 0.3) +
  geom_point(size = 1.9, color = "#2F3B52", stroke = 0.25, alpha = 0.9) +
  scale_shape_manual(values = c(Pre = 21, Week1 = 22, Week2 = 23,
                                Month1 = 24, Year3 = 25),
                     labels = TIME_LABELS, name = "Time window") +
  scale_fill_gradient2(low = "#E45756", mid = "#F7F7F7", high = "#4C78A8",
                      midpoint = median(omic_scores$eGFR, na.rm = TRUE),
                      na.value = "#F1F3F5", name = "eGFR") +
  facet_wrap(~ facet_label, scales = "free", nrow = 1) +
  labs(x = "Axis 1", y = "Axis 2",
       title = "A  Ordination colored by eGFR") +
  guides(fill = guide_colorbar(order = 1),
         shape = guide_legend(override.aes = list(fill = "white", color = "#2F3B52"), order = 2)) +
  theme_nature_pub(7) +
  theme(legend.position = "right")

save_fig_pdf(p2A, "Fig2A_ordination_eGFR", width = 9.0, height = 2.8)

# =====================================================================
# Fig2B : Ordination colored by Cr
# =====================================================================
message("\n[Fig2B] Ordination colored by Cr ...")

p2B <- ggplot(omic_scores,
              aes(Axis1, Axis2, fill = Cr, shape = time_window)) +
  geom_hline(yintercept = 0, color = "#EEF2F7", linewidth = 0.3) +
  geom_vline(xintercept = 0, color = "#EEF2F7", linewidth = 0.3) +
  geom_point(size = 1.9, color = "#2F3B52", stroke = 0.25, alpha = 0.9) +
  scale_shape_manual(values = c(Pre = 21, Week1 = 22, Week2 = 23,
                                Month1 = 24, Year3 = 25),
                     labels = TIME_LABELS, name = "Time window") +
  scale_fill_gradient2(low = "#4C78A8", mid = "#F7F7F7", high = "#E45756",
                      midpoint = median(omic_scores$Cr, na.rm = TRUE), trans = "log10",
                      na.value = "#F1F3F5", name = "Cr (μmol/L)") +
  facet_wrap(~ facet_label, scales = "free", nrow = 1) +
  labs(x = "Axis 1", y = "Axis 2",
       title = "B  Ordination colored by Cr") +
  theme_nature_pub(7) +
  theme(legend.position = "right")

save_fig_pdf(p2B, "Fig2B_ordination_Cr", width = 9.0, height = 2.8)

# =====================================================================
# Fig2C : PERMANOVA with time window and renal indices
# =====================================================================
message("\n[Fig2C] PERMANOVA full cohort ...")

run_adonis <- function(d, formula_str, sub_data) {
  ids <- intersect(attr(d, "Labels"), sub_data$company_id)
  d2 <- as.dist(as.matrix(d)[ids, ids])
  dat <- sub_data %>% filter(company_id %in% ids) %>%
    arrange(match(company_id, ids))
  set.seed(1)
  res <- vegan::adonis2(as.formula(paste("d2 ~", formula_str)),
                        data = dat, by = "terms", permutations = 999)
  rn <- rownames(res)
  tibble(
    variable = rn[!rn %in% c("Residual", "Total")],
    R2  = res$R2[rn %in% rn[!rn %in% c("Residual", "Total")]],
    Fst = res$F [rn %in% rn[!rn %in% c("Residual", "Total")]],
    p   = res$`Pr(>F)`[rn %in% rn[!rn %in% c("Residual", "Total")]]
  )
}

models <- list(
  c("time_window",            "time_window"),
  c("eGFR_only",              "eGFR"),
  c("Cr_only",                "Cr"),
  c("CysC_only",              "CysC"),
  c("time_window_plus_eGFR",  "time_window + eGFR"),
  c("time_window_plus_Cr",    "time_window + Cr"),
  c("time_window_plus_CysC",  "time_window + CysC")
)

permanova_full <- list()
for (omic_name in names(omic_dist)) {
  d <- omic_dist[[omic_name]]
  for (m in models) {
    sub <- clin_lookup %>%
      filter(company_id %in% attr(d, "Labels")) %>%
      filter(!is.na(time_window))
    needed <- str_extract_all(m[2], "(eGFR|Cr|CysC)")[[1]] %>% unique()
    for (v in needed) sub <- sub %>% filter(!is.na(.data[[v]]))
    if (nrow(sub) < 8) next
    res <- run_adonis(d, m[2], sub)
    permanova_full[[length(permanova_full) + 1]] <- res %>%
      mutate(omic = omic_name, model = m[1], n = nrow(sub))
  }
}
permanova_full_df <- bind_rows(permanova_full) %>%
  group_by(omic, model) %>%
  mutate(q = p.adjust(p, method = "BH")) %>%
  ungroup() %>%
  mutate(omic = factor(omic, levels = names(omic_dist)))

save_fig_data(permanova_full_df, "Fig2C_PERMANOVA_results.csv")

# Plot — stacked R² for each model (decompose by variable)
plot_df_C <- permanova_full_df %>%
  filter(model %in% c("time_window_plus_eGFR",
                      "time_window_plus_Cr",
                      "time_window_plus_CysC")) %>%
  mutate(model_lab = recode(model,
           "time_window_plus_eGFR" = "TW + eGFR",
           "time_window_plus_Cr"   = "TW + Cr",
           "time_window_plus_CysC" = "TW + CysC"),
         var_lab = ifelse(variable == "time_window",
                          "Time window", as.character(variable)),
         var_lab = factor(var_lab,
                          levels = c("Time window", "eGFR", "Cr", "CysC")))

p2C <- ggplot(plot_df_C,
              aes(model_lab, R2, fill = var_lab)) +
  geom_col(position = "stack", width = 0.55, color = "white", linewidth = 0.3) +
  geom_text(aes(label = sprintf("R²=%.2f", R2)),
            position = position_stack(vjust = 0.5),
            size = 1.9, color = "grey15") +
  scale_fill_manual(values = c("Time window" = "#4C78A8",
                                "eGFR"        = "#72B7B2",
                                "Cr"          = "#E45756",
                                "CysC"        = "#F28E2B"),
                    name = "Term") +
  facet_wrap(~ omic, nrow = 1) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.1))) +
  labs(x = NULL, y = "PERMANOVA R²",
       title = "C  Time window + renal index models (full cohort)") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))

save_fig_pdf(p2C, "Fig2C_PERMANOVA_time_renal", width = 9.0, height = 3.0)

# =====================================================================
# Fig2D : Post-Tx-only PERMANOVA
# =====================================================================
message("\n[Fig2D] Post-Tx-only PERMANOVA ...")

post_clin <- clin_lookup %>% filter(time_window != "Pre")
permanova_post <- list()
for (omic_name in names(omic_dist)) {
  d <- omic_dist[[omic_name]]
  ids <- intersect(attr(d, "Labels"), post_clin$company_id)
  if (length(ids) < 8) next
  d2 <- as.dist(as.matrix(d)[ids, ids])
  for (v in c("eGFR", "Cr", "CysC")) {
    sub <- post_clin %>% filter(company_id %in% ids) %>%
      filter(!is.na(.data[[v]])) %>% arrange(match(company_id, ids))
    if (nrow(sub) < 8) next
    ids2 <- sub$company_id
    d3 <- as.dist(as.matrix(d2)[ids2, ids2])
    set.seed(1)
    res <- vegan::adonis2(as.formula(paste("d3 ~", v)),
                          data = sub, permutations = 999, by = "terms")
    permanova_post[[length(permanova_post) + 1]] <- tibble(
      omic = omic_name, variable = v,
      R2 = res$R2[1], Fst = res$F[1], p = res$`Pr(>F)`[1],
      n = nrow(sub)
    )
  }
}
permanova_post_df <- bind_rows(permanova_post) %>%
  mutate(q = p.adjust(p, method = "BH"),
         omic = factor(omic, levels = names(omic_dist)),
         variable = factor(variable, levels = c("eGFR", "Cr", "CysC")))
save_fig_data(permanova_post_df, "Fig2D_postTx_PERMANOVA_results.csv")

p2D <- ggplot(permanova_post_df,
              aes(variable, R2,
                  fill = ifelse(p < 0.05, as.character(omic), "ns"))) +
  geom_col(width = 0.55, color = "#2F3B52", linewidth = 0.3) +
  geom_text(aes(label = sprintf("R²=%.2f", R2)),
            vjust = -0.2, size = 2.0, color = "grey15") +
  facet_wrap(~ omic, nrow = 1) +
  scale_fill_manual(values = c("Metagenome (genus)" = "#4C78A8",
                                "Metaproteome (core)" = "#72B7B2",
                                "Metabolome (Level 1-3)" = "#F28E2B",
                                "ns" = "#DCE9F6"),
                    guide = "none") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.25))) +
  labs(x = NULL, y = "PERMANOVA R²",
       title = "D  Post-transplant-only renal index PERMANOVA") +
  theme_nature_pub(7)

save_fig_pdf(p2D, "Fig2D_postTx_PERMANOVA", width = 8.0, height = 2.8)

# =====================================================================
# Fig2E : Variance partitioning summary
# =====================================================================
message("\n[Fig2E] Variance partitioning ...")

# For each omics: time alone, time+eGFR, partition into time-only,
# eGFR-after-time, residual
vp_rows <- list()
for (omic_name in names(omic_dist)) {
  d <- omic_dist[[omic_name]]
  sub <- clin_lookup %>% filter(company_id %in% attr(d, "Labels"),
                                  !is.na(eGFR), !is.na(time_window)) %>%
    arrange(match(company_id, attr(d, "Labels")))
  ids <- sub$company_id
  d_sub <- as.dist(as.matrix(d)[ids, ids])
  set.seed(1)
  full_mod <- vegan::adonis2(d_sub ~ time_window + eGFR, data = sub,
                             permutations = 999, by = "terms")
  set.seed(1)
  rev_mod  <- vegan::adonis2(d_sub ~ eGFR + time_window, data = sub,
                             permutations = 999, by = "terms")
  R2_tw_alone     <- rev_mod$R2[2]    # time after eGFR (= unique TW)
  R2_egfr_alone   <- full_mod$R2[2]   # eGFR after TW (= unique eGFR)
  set.seed(1)
  tw_only         <- vegan::adonis2(d_sub ~ time_window, data = sub,
                                    permutations = 999)$R2[1]
  set.seed(1)
  egfr_only       <- vegan::adonis2(d_sub ~ eGFR, data = sub,
                                    permutations = 999)$R2[1]
  R2_shared <- (tw_only + egfr_only) - (R2_tw_alone + R2_egfr_alone) -
               (tw_only + egfr_only - full_mod$R2[1] - full_mod$R2[2])
  R2_shared <- max(0, tw_only - R2_tw_alone)  # simpler safe approximation
  R2_residual <- 1 - (R2_tw_alone + R2_egfr_alone + R2_shared)
  vp_rows[[length(vp_rows) + 1]] <- tibble(
    omic = omic_name, n = nrow(sub),
    R2_time_unique = R2_tw_alone,
    R2_eGFR_unique = R2_egfr_alone,
    R2_shared      = R2_shared,
    R2_residual    = R2_residual
  )
}
vp_df <- bind_rows(vp_rows) %>%
  mutate(omic = factor(omic, levels = names(omic_dist)))
save_fig_data(vp_df, "Fig2E_variance_partitioning.csv")

vp_long <- vp_df %>%
  pivot_longer(c(R2_time_unique, R2_eGFR_unique, R2_shared, R2_residual),
               names_to = "component", values_to = "R2") %>%
  mutate(component = factor(component,
    levels = c("R2_time_unique", "R2_shared", "R2_eGFR_unique", "R2_residual"),
    labels = c("Time window (unique)",
               "Shared (TW ∩ eGFR)",
               "eGFR (unique)",
               "Residual")))

p2E <- ggplot(vp_long, aes(omic, R2, fill = component)) +
  geom_col(position = "stack", width = 0.55, color = "white", linewidth = 0.3) +
  geom_text(aes(label = ifelse(R2 > 0.04, sprintf("%.2f", R2), "")),
            position = position_stack(vjust = 0.5),
            size = 2.1, color = "grey15") +
  scale_fill_manual(values = c("Time window (unique)" = "#4C78A8",
                                "Shared (TW ∩ eGFR)"  = "#72B7B2",
                                "eGFR (unique)"        = "#E45756",
                                "Residual"             = "#F3E8D5"),
                    name = "Variance component") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05)),
                     limits = c(0, 1)) +
  labs(x = NULL, y = "Proportion of variance",
       title = "E  Variance partitioning: time window vs eGFR") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5))

save_fig_pdf(p2E, "Fig2E_variance_partitioning", width = 6.5, height = 3.2)

# =====================================================================
# Combined Fig 2
# =====================================================================
message("\n[Fig2] Combined ...")

fig2 <- (p2A + labs(title = NULL)) /
        (p2B + labs(title = NULL)) /
        (p2C + labs(title = NULL)) /
        (p2D + labs(title = NULL) | p2E + labs(title = NULL)) +
        plot_layout(heights = c(1, 1, 1, 1)) +
        plot_annotation(tag_levels = list(c("A", "B", "C", "D", "E"))) &
        theme(plot.tag = element_text(face = "bold", size = 11))

save_fig_pdf(fig2, "Fig2_TrpIS_global_renal_function",
             width = 11, height = 11)

message("\nFig2 (global renal function) complete.\n")
