# =====================================================================
# 13_Fig5_robustness_NEW.R
# Internal robustness of the Trp-IS composite–eGFR association.
# Replaces the old "extreme-sample sensitivity" Fig5.
# Panels:
#   A  Full-cohort vs post-transplant-only scatter
#   B  Robustness summary (rho with 95% CI where available)
#   C  Leave-one-participant-out distribution
#   D  Composite vs single features (drop-IS / IS-alone / layer scores)
#   E  Structure-matched random-composite null distribution
#   F  Participant-level cluster bootstrap distribution
#
# PREREQUISITES (run first, in order):
#   source("R/setup.R")
#   source("11_Fig3_TrpIS_module_ranking.R")   # creates score_df, mod_mat_log
#   # objects also needed from setup/earlier: genus, metab, clin_lookup, master
# =====================================================================

suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(ggplot2); library(purrr); library(patchwork)
})

set.seed(1)

# ---------------------------------------------------------------------
# 0. Assemble analysis frame (score + eGFR + patient id + time window)
# ---------------------------------------------------------------------
sp <- score_df %>%
  left_join(master %>% select(company_id, patient_hosp_id), by = "company_id") %>%
  filter(!is.na(TrpIS_integrated_score), !is.na(eGFR))

stopifnot(nrow(sp) > 0)

rho_full <- cor(sp$TrpIS_integrated_score, sp$eGFR, method = "spearman")
ct_full  <- suppressWarnings(cor.test(sp$TrpIS_integrated_score, sp$eGFR, method = "spearman"))

# ---------------------------------------------------------------------
# 1. Post-transplant only
# ---------------------------------------------------------------------
sp_post <- sp %>% filter(time_window != "Pre")
ct_post <- suppressWarnings(cor.test(sp_post$TrpIS_integrated_score, sp_post$eGFR, method = "spearman"))

# ---------------------------------------------------------------------
# 2. Time-window-adjusted partial Spearman (residual method)
# ---------------------------------------------------------------------
dtw <- sp %>% filter(!is.na(time_window))
dtw$score_resid <- residuals(lm(rank(TrpIS_integrated_score) ~ time_window, data = dtw))
dtw$egfr_resid  <- residuals(lm(rank(eGFR) ~ time_window, data = dtw))
ct_adj <- suppressWarnings(cor.test(dtw$score_resid, dtw$egfr_resid, method = "spearman"))

# ---------------------------------------------------------------------
# 3. Complete three-layer samples (n=37)
# ---------------------------------------------------------------------
full3 <- score_df %>%
  filter(!is.na(TrpIS_genus_score), !is.na(TrpIS_protein_score),
         !is.na(TrpIS_metab_score), !is.na(eGFR))
ct_full3 <- suppressWarnings(cor.test(full3$TrpIS_integrated_score, full3$eGFR, method = "spearman"))

# ---------------------------------------------------------------------
# 4. Leave-one-participant-out
# ---------------------------------------------------------------------
patients <- unique(sp$patient_hosp_id)
loo <- sapply(patients, function(pid) {
  d <- sp %>% filter(patient_hosp_id != pid)
  suppressWarnings(cor(d$TrpIS_integrated_score, d$eGFR, method = "spearman"))
})

# ---------------------------------------------------------------------
# 5. Participant-level cluster bootstrap (2000; percentile CI)
# ---------------------------------------------------------------------
B <- 2000
boot_rho <- replicate(B, {
  samp_pts <- sample(patients, length(patients), replace = TRUE)
  d <- do.call(rbind, lapply(samp_pts, function(p) sp[sp$patient_hosp_id == p, ]))
  suppressWarnings(cor(d$TrpIS_integrated_score, d$eGFR, method = "spearman"))
})
boot_ci <- quantile(boot_rho, c(.025, .975), na.rm = TRUE)

# ---------------------------------------------------------------------
# 6. Drop-IS composite / IS alone / layer scores
# ---------------------------------------------------------------------
# IS-alone
is_id <- metab_feat %>%
  filter(grepl("Indoxyl sulph|Indoxyl sulf", Name, ignore.case = TRUE),
         Level %in% c("level1", "level2"))
is_v <- metab %>% filter(metabolite_id == is_id$metabolite_id[1]) %>% select(company_id, value)
di <- score_df %>% left_join(is_v, by = "company_id") %>% filter(!is.na(value), !is.na(eGFR))
rho_is_alone <- cor(di$value, di$eGFR, method = "spearman")

# Composite without IS
trp_metab_kw_noIS <- trp_metab_kw[names(trp_metab_kw) != "IS"]
ids_noIS <- map_chr(trp_metab_kw_noIS, function(p) {
  hit <- metab_feat %>% filter(grepl(p, Name, ignore.case = TRUE), Level %in% c("level1", "level2"))
  if (nrow(hit) == 0) NA_character_ else hit$metabolite_id[1]
})
mw <- metab %>% filter(metabolite_id %in% ids_noIS[!is.na(ids_noIS)]) %>%
  pivot_wider(names_from = metabolite_id, values_from = value, values_fill = NA)
mm <- as.matrix(mw %>% select(-company_id)); rownames(mm) <- mw$company_id
mm[is.na(mm)] <- 0
metab_noIS <- rowMeans(scale(log2(mm + 1)), na.rm = TRUE)
d_noIS <- score_df %>%
  mutate(mnoIS = metab_noIS[match(company_id, names(metab_noIS))]) %>%
  rowwise() %>%
  mutate(int_noIS = mean(c(TrpIS_genus_score, TrpIS_protein_score, mnoIS), na.rm = TRUE)) %>%
  ungroup() %>% filter(!is.na(int_noIS), !is.na(eGFR))
rho_noIS <- cor(d_noIS$int_noIS, d_noIS$eGFR, method = "spearman")

# Layer scores vs eGFR (full cohort)
lyr <- score_df %>% filter(!is.na(eGFR))
rho_genus <- cor(lyr$TrpIS_genus_score,   lyr$eGFR, method = "spearman", use = "complete.obs")
rho_prot  <- cor(lyr$TrpIS_protein_score, lyr$eGFR, method = "spearman", use = "complete.obs")
rho_metab <- cor(lyr$TrpIS_metab_score,   lyr$eGFR, method = "spearman", use = "complete.obs")

# ---------------------------------------------------------------------
# 7. Structure-matched random-composite null
#    (randomise genus + metabolite features; retain observed protein module)
# ---------------------------------------------------------------------
n_genus_real <- 4
n_metab_real <- 5
genus_wide <- genus %>% pivot_wider(names_from = genus, values_from = rel_abund, values_fill = 0)
gm <- as.matrix(genus_wide %>% select(-company_id)); rownames(gm) <- genus_wide$company_id
metab_wide <- metab %>% pivot_wider(names_from = metabolite_id, values_from = value, values_fill = NA)
mmx <- as.matrix(metab_wide %>% select(-company_id)); rownames(mmx) <- metab_wide$company_id
mmx[is.na(mmx)] <- 0
prot_cols_real <- intersect(c("TrpIS_indole", "Kynurenine_pathway"), colnames(mod_mat_log))
prot_score_real <- rowMeans(scale(mod_mat_log[, prot_cols_real, drop = FALSE]), na.rm = TRUE)
eg <- setNames(clin_lookup$eGFR, clin_lookup$company_id)

n_genus_bg <- ncol(gm); n_metab_bg <- ncol(mmx)  # background pool sizes (report in Methods)

rand_rho <- function() {
  g_pick <- sample(colnames(gm),  n_genus_real)
  m_pick <- sample(colnames(mmx), n_metab_real)
  g_s <- rowMeans(scale(log2(gm[, g_pick, drop = FALSE] * 100 + 1)), na.rm = TRUE)
  m_s <- rowMeans(scale(log2(mmx[, m_pick, drop = FALSE] + 1)),      na.rm = TRUE)
  ids <- rownames(mod_mat_log)
  int <- sapply(ids, function(id) mean(c(g_s[id], prot_score_real[id], m_s[id]), na.rm = TRUE))
  y <- eg[ids]; ok <- !is.na(int) & !is.na(y)
  suppressWarnings(cor(int[ok], y[ok], method = "spearman"))
}
null_rho <- replicate(2000, rand_rho())
b_ge <- sum(abs(null_rho) >= abs(rho_full), na.rm = TRUE)
perm_p <- (b_ge + 1) / (2000 + 1)

# ---------------------------------------------------------------------
# Save all numbers (authoritative source data for Fig5)
# ---------------------------------------------------------------------
robust_tab <- tibble(
  analysis = c("Full cohort", "Post-transplant only", "Time-window-adjusted (partial)",
               "Complete three-layer (n=37)", "LOPO range", "Cluster bootstrap 95% CI",
               "Drop IS", "IS alone", "Random null (perm P)"),
  value = c(
    sprintf("rho=%.3f, p=%.4f, n=%d", rho_full, ct_full$p.value, nrow(sp)),
    sprintf("rho=%.3f, p=%.4f, n=%d", ct_post$estimate, ct_post$p.value, nrow(sp_post)),
    sprintf("partial rho=%.3f, p=%.4f", ct_adj$estimate, ct_adj$p.value),
    sprintf("rho=%.3f, p=%.4f, n=%d", ct_full3$estimate, ct_full3$p.value, nrow(full3)),
    sprintf("%.3f to %.3f (%d iters)", min(loo), max(loo), length(loo)),
    sprintf("%.3f to %.3f", boot_ci[1], boot_ci[2]),
    sprintf("rho=%.3f", rho_noIS),
    sprintf("rho=%.3f", rho_is_alone),
    sprintf("perm P=%.4f, median null rho=%.3f, genus_pool=%d, metab_pool=%d",
            perm_p, median(null_rho, na.rm = TRUE), n_genus_bg, n_metab_bg))
)
save_fig_data(robust_tab, "Fig5_robustness_summary.csv")
print(robust_tab)

# =====================================================================
# PLOTS
# =====================================================================
# Panel A: full vs post scatter
dfA <- bind_rows(
  sp      %>% transmute(score = TrpIS_integrated_score, eGFR, set = "Full cohort"),
  sp_post %>% transmute(score = TrpIS_integrated_score, eGFR, set = "Post-transplant only"))
p5A <- ggplot(dfA, aes(score, eGFR, color = set)) +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE, linewidth = 0.4) +
  geom_point(size = 1.3, alpha = 0.8) +
  scale_color_manual(values = c("Full cohort" = "#8A8A8A", "Post-transplant only" = "#4C78A8"),
                     name = NULL) +
  labs(x = "Trp-IS composite (z)", y = "eGFR (mL/min/1.73 m2)",
       title = sprintf("Full rho=%.2f | Post rho=%.2f", rho_full, ct_post$estimate)) +
  theme_nature_pub(7)

# Panel B: robustness summary point estimates
dfB <- tibble(
  analysis = factor(c("Full", "Post-only", "TW-adjusted", "3-layer (n=37)", "Drop IS"),
                    levels = rev(c("Full", "Post-only", "TW-adjusted", "3-layer (n=37)", "Drop IS"))),
  rho = c(rho_full, ct_post$estimate, ct_adj$estimate, ct_full3$estimate, rho_noIS))
p5B <- ggplot(dfB, aes(rho, analysis)) +
  geom_vline(xintercept = 0, color = "#999999", linewidth = 0.3) +
  geom_segment(aes(x = 0, xend = rho, yend = analysis), linewidth = 0.4, color = "#B279A2") +
  geom_point(size = 2.5, color = "#B279A2") +
  xlim(0, 0.6) +
  labs(x = "Spearman rho with eGFR", y = NULL, title = "Composite robustness") +
  theme_nature_pub(7)

# Panel C: LOPO distribution
p5C <- ggplot(tibble(rho = loo), aes(rho)) +
  geom_histogram(bins = 15, fill = "#72B7B2", color = "white") +
  geom_vline(xintercept = rho_full, color = "#E45756", linewidth = 0.5) +
  labs(x = "rho (leave-one-participant-out)", y = "Count",
       title = sprintf("LOPO: %.2f-%.2f", min(loo), max(loo))) +
  theme_nature_pub(7)

# Panel D: composite vs single features
dfD <- tibble(
  feature = factor(c("Integrated", "Genus", "Protein", "Metabolite", "Drop-IS", "IS alone"),
                   levels = rev(c("Integrated", "Genus", "Protein", "Metabolite", "Drop-IS", "IS alone"))),
  rho = c(rho_full, rho_genus, rho_prot, rho_metab, rho_noIS, rho_is_alone),
  grp = c("Composite", "Layer", "Layer", "Layer", "Composite", "Single"))
p5D <- ggplot(dfD, aes(rho, feature, color = grp)) +
  geom_vline(xintercept = 0, color = "#999999", linewidth = 0.3) +
  geom_segment(aes(x = 0, xend = rho, yend = feature), linewidth = 0.4) +
  geom_point(size = 2.5) +
  scale_color_manual(values = c("Composite" = "#B279A2", "Layer" = "#4C78A8", "Single" = "#E45756"),
                     name = NULL) +
  labs(x = "Spearman rho with eGFR", y = NULL, title = "Composite vs single features") +
  theme_nature_pub(7)

# Panel E: random null
p5E <- ggplot(tibble(rho = null_rho), aes(rho)) +
  geom_histogram(bins = 40, fill = "#CCCCCC", color = "white") +
  geom_vline(xintercept = rho_full, color = "#E45756", linewidth = 0.6) +
  labs(x = "rho (random composites)", y = "Count",
       title = sprintf("Random null: perm P=%.4f", perm_p)) +
  theme_nature_pub(7)

# Panel F: cluster bootstrap
p5F <- ggplot(tibble(rho = boot_rho), aes(rho)) +
  geom_histogram(bins = 40, fill = "#F2CF5B", color = "white") +
  geom_vline(xintercept = boot_ci, color = "#4C78A8", linetype = "dashed", linewidth = 0.4) +
  geom_vline(xintercept = rho_full, color = "#E45756", linewidth = 0.6) +
  labs(x = "rho (participant cluster bootstrap)", y = "Count",
       title = sprintf("Cluster bootstrap 95%% CI: %.2f-%.2f", boot_ci[1], boot_ci[2])) +
  theme_nature_pub(7)

fig5 <- (p5A | p5B | p5C) / (p5D | p5E | p5F) +
  plot_annotation(tag_levels = "A") & panel_tag_theme
save_fig_pdf(fig5, "Fig5_robustness", width = 13, height = 7.5)
message("\nFig5 (robustness) complete.\n")
