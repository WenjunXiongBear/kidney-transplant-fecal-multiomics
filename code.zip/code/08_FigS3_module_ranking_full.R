# =====================================================================
# 16_FigS3_module_ranking_full.R
# Supplementary Figure S3 — Full functional-module x renal-index
# association under three nested analytical settings,
# raw / time-window adjusted / post-transplant only.
# =====================================================================

source("R/setup.R")

master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
clin      <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
prot_anno <- readRDS(file.path(PROC_DIR, "metaprot_annotation.rds"))
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)

prot_pass <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)

# Same module definitions as Fig3
modules_def <- list(
  TrpIS_indole = list(kos = c("K01667","K00179","K00180","K01695","K01696"),
                       kw  = "tryptophan|indole|tryptophanase|indolepyruvate"),
  Kynurenine_pathway = list(kos = c("K00466","K01556","K01432","K00816"),
                             kw  = "kynurenine|kynureninase|kmo"),
  pCresol_aromatic = list(kos = c("K22354","K22355","K22356","K01692",
                                   "K05359","K00822","K01657"),
                           kw  = "p-cresol|p-hydroxyphenylacetate|tyrosine"),
  SCFA_related = list(kos = c("K00925","K00929","K01034","K01035","K00248"),
                       kw  = "butyrate|butyryl|propionate|acetate kinase|short-chain"),
  Bile_acid = list(kos = c("K01442","K07007"),
                    kw  = "bile acid|cholate|deoxycholate|bsh"),
  AA_metabolism = list(kos = NULL,
                        kw = "amino acid|alanine|arginine|aspartate|glutamate|histidine|leucine|lysine|methionine|phenylalanine|proline|serine|threonine|valine"),
  Carbohydrate_metab = list(kos = NULL,
                             kw = "glycolysis|pyruvate|fructose|galactose|maltose|carbohydrate|glucose"),
  Energy_metab = list(kos = NULL,
                       kw = "ATP synthase|cytochrome|NADH|electron transport|TCA|citrate cycle|oxidative phosphorylation"),
  Stress_transport = list(kos = NULL,
                           kw = "ABC transporter|chaperone|heat shock|oxidative stress|osmotic stress|hsp")
)

prot_module_long <- map_dfr(names(modules_def), function(mod) {
  spec <- modules_def[[mod]]
  hit <- prot_anno %>%
    filter((!is.null(spec$kos) & KO_id %in% spec$kos) |
           (!is.null(spec$kw)  & grepl(spec$kw, ko_definition,
                                       ignore.case = TRUE))) %>%
    select(protein_id, KO_id, ko_definition, Taxonomy_genus,
           Taxonomy_species)
  if (nrow(hit) == 0) return(NULL)
  hit %>% mutate(module = mod)
}) %>% distinct(protein_id, module, .keep_all = TRUE)

mod_per_sample <- metaprot %>%
  filter(company_id %in% prot_pass) %>%
  inner_join(prot_module_long %>% select(protein_id, module),
             by = "protein_id") %>%
  group_by(company_id, module) %>%
  summarise(abund = sum(abundance, na.rm = TRUE), .groups = "drop")

mod_wide <- mod_per_sample %>%
  pivot_wider(names_from = module, values_from = abund, values_fill = 0)
mod_mat <- as.matrix(mod_wide %>% select(-company_id))
rownames(mod_mat) <- mod_wide$company_id
mod_mat_log <- log2(mod_mat + 1)

# =====================================================================
# Statistical helpers
# =====================================================================
spearman_test <- function(x, y) {
  ok <- complete.cases(x, y)
  if (sum(ok) < 8) return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  rs <- suppressWarnings(cor.test(x[ok], y[ok], method = "spearman",
                                  exact = FALSE))
  c(rho = unname(rs$estimate), p = rs$p.value, n = sum(ok))
}
partial_lm_tw <- function(x, y, tw) {
  ok <- complete.cases(x, y, tw)
  if (sum(ok) < 10) return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  fit <- lm(rank(y[ok]) ~ rank(x[ok]) + factor(tw[ok]))
  cc <- summary(fit)$coefficients
  if (!"rank(x[ok])" %in% rownames(cc))
    return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  t <- cc["rank(x[ok])","t value"]; p <- cc["rank(x[ok])","Pr(>|t|)"]
  df <- summary(fit)$df[2]
  rho <- sign(t) * sqrt(t^2 / (t^2 + df))
  c(rho = rho, p = p, n = sum(ok))
}

clin_lookup <- clin %>%
  select(company_id, time_window,
         Cr = cr_umol_L, CysC = cysC_mg_L, eGFR = egfr_ckdepi)

# =====================================================================
# Build three association tables: raw / TW-adj / post-Tx
# =====================================================================
compute_long <- function(scenario) {
  results <- list()
  for (mod in colnames(mod_mat_log)) {
    for (idx in c("Cr", "CysC", "eGFR")) {
      common <- intersect(rownames(mod_mat_log), clin_lookup$company_id)
      x <- mod_mat_log[common, mod]
      y <- setNames(clin_lookup[[idx]],          clin_lookup$company_id)[common]
      tw <- setNames(as.character(clin_lookup$time_window),
                     clin_lookup$company_id)[common]
      if (scenario == "raw") {
        st <- spearman_test(x, y)
      } else if (scenario == "tw_adj") {
        st <- partial_lm_tw(x, y, tw)
      } else if (scenario == "post_tx") {
        keep <- tw != "Pre"
        st <- spearman_test(x[keep], y[keep])
      }
      results[[length(results)+1]] <- tibble(
        module = mod, clinical_index = idx, scenario = scenario,
        rho = st["rho"], p = st["p"], n = st["n"])
    }
  }
  bind_rows(results) %>%
    group_by(clinical_index) %>%
    mutate(q = p.adjust(p, method = "BH")) %>%
    ungroup()
}

raw_df    <- compute_long("raw")
adj_df    <- compute_long("tw_adj")
post_df   <- compute_long("post_tx")

save_fig_data(bind_rows(raw_df, adj_df, post_df),
              "FigS3_module_full_association_table.csv")

# =====================================================================
# Heatmap factory
# =====================================================================
plot_heatmap <- function(d, title) {
  d <- d %>%
    mutate(module = factor(module, levels = names(modules_def)),
           clinical_index = factor(clinical_index,
                                    levels = c("Cr","CysC","eGFR")),
           star = case_when(
             !is.na(q) & q < 0.05 ~ "*",
             !is.na(q) & q < 0.10 ~ "·",
             TRUE                  ~ ""))

  ggplot(d, aes(clinical_index, module, fill = rho)) +
    geom_tile(color = "white", linewidth = 0.4) +
    geom_text(aes(label = sprintf("%.2f%s", rho, star)),
              size = 2.1, color = "grey15") +
    scale_fill_gradient2(low = HEATMAP_LOW, mid = HEATMAP_MID,
                         high = HEATMAP_HIGH, midpoint = 0,
                         limits = c(-1, 1), name = "ρ") +
    scale_y_discrete(limits = rev) +
    labs(x = NULL, y = NULL, title = title) +
    theme_nature_pub(7) +
    theme(panel.grid = element_blank(),
          axis.line = element_blank(),
          axis.text.x = element_text(face = "bold"))
}

pS3A <- plot_heatmap(raw_df,  "A  Raw Spearman ρ across all functional modules")
pS3B <- plot_heatmap(adj_df,  "B  Time-window-adjusted partial ρ")
pS3C <- plot_heatmap(post_df, "C  Post-transplant-only Spearman ρ")

save_fig_pdf(pS3A, "FigS3A_raw_module_heatmap",     width = 5.0, height = 4.5)
save_fig_pdf(pS3B, "FigS3B_tw_adj_module_heatmap",  width = 5.0, height = 4.5)
save_fig_pdf(pS3C, "FigS3C_post_tx_module_heatmap", width = 5.0, height = 4.5)

# =====================================================================
# Combined Fig S3
# =====================================================================
message("\n[FigS3] Combined ...")

figS3 <- (pS3A | pS3B | pS3C) +
  plot_layout(guides = "collect") +
  plot_annotation(tag_levels = list(c("A", "B", "C"))) &
  theme(plot.tag = element_text(face = "bold", size = 11),
        legend.position = "right")

save_fig_pdf(figS3, "FigS3_module_ranking_full",
             width = 14, height = 5)
message("\nFig S3 complete.\n")
