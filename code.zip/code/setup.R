# =====================================================================
# setup.R — shared configuration, palette, theme, helpers.
# Sourced by every numbered script.
# =====================================================================

# --- Paths -----------------------------------------------------------
PROJECT_ROOT <- normalizePath(".", winslash = "/", mustWork = TRUE)
RAW_DIR      <- file.path(PROJECT_ROOT, "data", "raw")
PROC_DIR     <- file.path(PROJECT_ROOT, "data", "processed")
TABLE_DIR    <- file.path(PROJECT_ROOT, "results", "tables")
FIG_DIR      <- file.path(PROJECT_ROOT, "results", "figures")
for (d in c(PROC_DIR, TABLE_DIR, FIG_DIR)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

# --- Required packages -----------------------------------------------
required_pkgs <- c(
  "tidyverse", "readxl", "patchwork", "scales",
  "RColorBrewer", "vegan", "ape",
  "ComplexUpset", "ggrepel",
  "igraph", "ggraph"
)
miss <- setdiff(required_pkgs, rownames(installed.packages()))
if (length(miss)) install.packages(miss, repos = "https://cloud.r-project.org")
invisible(lapply(required_pkgs, library, character.only = TRUE))

# --- Time windows ----------------------------------------------------
TIME_LEVELS <- c("Pre", "Week1", "Week2", "Month1", "Year3")
TIME_LABELS <- c(
  Pre    = "Pre-transplant",
  Week1  = "Post-Tx 1 week",
  Week2  = "Post-Tx 15 days",
  Month1 = "Post-Tx 1 month",
  Year3  = "Post-Tx 3 years"
)
# Nordic-style low-saturation palette
TIME_COLORS <- c(
  Pre    = "#4C566A",
  Week1  = "#5E81AC",
  Week2  = "#A3BE8C",
  Month1 = "#D08770",
  Year3  = "#BF616A"
)
LAYER_COLORS <- c(
  Genus      = "#4C78A8",
  Protein    = "#59A14F",
  Metabolite = "#F28E2B"
)
# Heatmap divergent
HEATMAP_LOW  <- "#4575B4"
HEATMAP_MID  <- "#FFFFFF"
HEATMAP_HIGH <- "#D73027"

# --- QC thresholds ---------------------------------------------------
PROT_HARD_FAIL  <- 1500
GENUS_PREV_MIN  <- 0.20
GENUS_ABUND_MIN <- 1e-4
PROT_PREV_MIN   <- 0.20
METAB_MISS_MAX  <- 0.30

# --- Nature-style publication theme ----------------------------------
theme_nature_pub <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = "Helvetica") +
    theme(
      panel.grid.major.y = element_line(color = "grey92", linewidth = 0.2),
      panel.grid.major.x = element_blank(),
      panel.grid.minor   = element_blank(),
      axis.line          = element_line(color = "black", linewidth = 0.3),
      axis.ticks         = element_line(color = "black", linewidth = 0.3),
      axis.title         = element_text(size = base_size + 1, color = "black"),
      axis.text          = element_text(size = base_size, color = "black"),
      legend.key.size    = unit(0.3, "cm"),
      legend.title       = element_text(size = base_size, color = "black"),
      legend.text        = element_text(size = base_size - 1, color = "black"),
      legend.box.spacing = unit(2, "pt"),
      strip.background   = element_blank(),
      strip.text         = element_text(size = base_size, face = "bold",
                                        margin = margin(2, 2, 2, 2)),
      plot.title         = element_text(size = base_size + 2, face = "bold",
                                        margin = margin(0, 0, 4, 0)),
      plot.tag           = element_text(size = base_size + 3, face = "bold"),
      plot.margin        = margin(4, 4, 4, 4)
    )
}

# --- Helpers ---------------------------------------------------------
read_xls_as_tsv <- function(path, encoding = "UTF-8") {
  readr::read_tsv(path, locale = locale(encoding = encoding),
                  show_col_types = FALSE, progress = FALSE)
}

# Encoding-agnostic clinical numeric parser
parse_clinical_numeric <- function(x) {
  s <- as.character(x)
  s <- gsub(",", ".", s, fixed = TRUE)
  s <- gsub("[^0-9.\\-]", "", s, perl = TRUE)
  suppressWarnings(as.numeric(s))
}

# CKD-EPI 2021 (race-free); Cr μmol/L → mg/dL via /88.4
calc_egfr_ckdepi2021 <- function(cr_umol_L, age, sex) {
  cr_mg_dL  <- cr_umol_L / 88.4
  is_female <- sex %in% c("F", "Female", "female", "女")
  k         <- ifelse(is_female, 0.7,    0.9)
  alpha     <- ifelse(is_female, -0.241, -0.302)
  ratio     <- cr_mg_dL / k
  egfr <- 142 *
    pmin(ratio, 1)^alpha *
    pmax(ratio, 1)^(-1.200) *
    0.9938^age *
    ifelse(is_female, 1.012, 1.0)
  egfr
}
egfr_to_stage <- function(egfr) {
  cut(egfr, breaks = c(-Inf, 15, 30, 45, 60, 90, Inf),
      labels = c("G5", "G4", "G3b", "G3a", "G2", "G1"), right = FALSE)
}

save_csv_excel <- function(df, fpath) {
  readr::write_excel_csv(df, fpath)
  message("  wrote: ", fpath)
}
save_fig_data <- function(df, fname) {
  save_csv_excel(df, file.path(TABLE_DIR, fname))
}
save_fig_pdf <- function(plot, fig_id, width, height) {
  out <- file.path(FIG_DIR, sprintf("%s.pdf", fig_id))
  ggsave(out, plot = plot, device = "pdf",
         width = width, height = height, units = "in", useDingbats = FALSE)
  message("  wrote: ", out)
}

message("setup.R loaded.")
