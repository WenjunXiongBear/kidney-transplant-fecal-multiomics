# =====================================================================
# 09_Fig1_TrpIS_cohort_renal_gradient.R
# Cohort structure and renal-function gradient for the Trp-IS thesis.
# =====================================================================

source("R/setup.R")



# ---------------------------------------------------------------------
# Local Nature-like visual system override (format-only; data/statistics unchanged)
# ---------------------------------------------------------------------
# Keep the analysis unchanged. This block only standardizes typography, borders,
# and a cleaner low-saturation palette across all figures.
TIME_COLORS <- setNames(c("#8A8A8A", "#4C78A8", "#72B7B2", "#F2CF5B", "#E45756"),
                        TIME_LEVELS)
RENAL_GROUP_COLORS <- c("Low eGFR" = "#E45756",
                        "Mid eGFR" = "#F2CF5B",
                        "High eGFR" = "#4C78A8")
LAYER_COLORS <- c("Genus" = "#4C78A8",
                  "Protein" = "#72B7B2",
                  "Metabolite" = "#F2CF5B",
                  "Renal" = "#E45756",
                  "Integrated" = "#B279A2",
                  "Score" = "#B279A2")
HEATMAP_LOW  <- "#4C78A8"
HEATMAP_MID  <- "#FFFFFF"
HEATMAP_HIGH <- "#E45756"
TEXT_COL <- "#222222"
AXIS_COL <- "#333333"
GRID_COL <- "#ECECEC"
BORDER_COL <- "#333333"

nature_panel <- theme(
  panel.border = element_rect(color = BORDER_COL, fill = NA, linewidth = 0.35),
  plot.title = element_text(face = "bold", color = TEXT_COL),
  axis.title = element_text(face = "bold", color = TEXT_COL),
  strip.text = element_text(face = "bold", color = TEXT_COL)
)

theme_nature_pub <- function(base_size = 7, base_family = "Helvetica") {
  base_size <- max(base_size, 8)
  theme_classic(base_size = base_size, base_family = base_family) %+replace%
    theme(
      text = element_text(color = TEXT_COL),
      plot.title = element_text(size = base_size + 1.2, face = "bold", hjust = 0, color = TEXT_COL),
      axis.title = element_text(size = base_size, face = "bold", color = TEXT_COL),
      axis.text = element_text(size = base_size - 1, color = "#333333"),
      axis.line = element_line(color = AXIS_COL, linewidth = 0.32),
      axis.ticks = element_line(color = AXIS_COL, linewidth = 0.28),
      axis.ticks.length = unit(1.5, "mm"),
      panel.border = element_rect(color = BORDER_COL, fill = NA, linewidth = 0.35),
      panel.grid.major.y = element_line(color = GRID_COL, linewidth = 0.25),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", color = TEXT_COL),
      legend.title = element_text(size = base_size - 1, face = "bold", color = TEXT_COL),
      legend.text = element_text(size = base_size - 1, color = "#333333"),
      legend.key.height = unit(3.8, "mm"),
      legend.key.width = unit(4.4, "mm"),
      plot.margin = margin(5, 5, 5, 5)
    )
}

panel_tag_theme <- theme(plot.tag = element_text(face = "bold", size = 12, color = TEXT_COL),
                         plot.tag.position = c(0.01, 0.99))



# ---------------------------------------------------------------------
# Helpers (local)
# ---------------------------------------------------------------------
trend_test <- function(x, group_factor) {
  ok <- complete.cases(x, group_factor)
  if (sum(ok) < 8) return(NA_real_)
  g <- as.numeric(as.factor(group_factor[ok]))
  suppressWarnings(cor.test(x[ok], g, method = "spearman", exact = FALSE)$p.value)
}

kruskal_p <- function(x, g) {
  ok <- complete.cases(x, g)
  if (sum(ok) < 8 || length(unique(g[ok])) < 2) return(NA_real_)
  suppressWarnings(kruskal.test(x[ok] ~ as.factor(g[ok]))$p.value)
}

# ---------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------
master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
clin      <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)
genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
prot_anno <- readRDS(file.path(PROC_DIR, "metaprot_annotation.rds"))
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
metab_feat<- read_csv(file.path(PROC_DIR, "metab_features.csv"),
                      show_col_types = FALSE)

prot_pass <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)

# ---------------------------------------------------------------------
# Trp-IS feature definitions
# ---------------------------------------------------------------------
trp_genera <- c("Bacteroides", "Alistipes", "Escherichia", "Fusobacterium")
trp_kos    <- c("K01667", "K00179", "K00180", "K01695", "K01696",
                "K00466", "K01556")
trp_metab_kw <- c(
  Tryptophan = "^L-Tryptophan$|^Tryptophan$",
  Indole     = "^Indole$",
  IS         = "Indoxyl sulph|Indoxyl sulf",
  IAA        = "Indole-3-acetic|Indoleacetic",
  Kynurenine = "^L-Kynurenine$|^Kynurenine$",
  KynA       = "Kynurenic acid"
)
trp_metab_ids <- map_chr(trp_metab_kw, function(p) {
  hit <- metab_feat %>%
    filter(grepl(p, Name, ignore.case = TRUE),
           Level %in% c("level1", "level2"))
  if (nrow(hit) == 0) NA_character_ else hit$metabolite_id[1]
})

# Per-sample availability flags for each Trp-IS layer
genus_per_sample <- genus %>% filter(genus %in% trp_genera) %>%
  group_by(company_id) %>% summarise(n_g = n(), .groups = "drop")
prot_for_ko <- prot_anno %>% filter(KO_id %in% trp_kos) %>%
  select(protein_id, KO_id)
prot_per_sample <- metaprot %>% filter(company_id %in% prot_pass) %>%
  inner_join(prot_for_ko, by = "protein_id") %>%
  group_by(company_id) %>% summarise(n_p = n(), .groups = "drop")
metab_per_sample <- metab %>%
  filter(metabolite_id %in% trp_metab_ids) %>%
  group_by(company_id) %>% summarise(n_m = n(), .groups = "drop")

avail <- master %>%
  transmute(
    company_id, time_window, sex, age,
    Clinical    = !is.na(cr_umol_L) | !is.na(cysC_mg_L),
    Renal       = !is.na(cr_umol_L) & !is.na(cysC_mg_L),
    Metagenome  = company_id %in% unique(genus$company_id),
    Metaproteome= company_id %in% prot_pass,
    Metabolome  = company_id %in% unique(metab$company_id)
  ) %>%
  left_join(clin %>% select(company_id, cr_umol_L, cysC_mg_L, egfr_ckdepi),
            by = "company_id") %>%
  left_join(genus_per_sample, by = "company_id") %>%
  left_join(prot_per_sample,  by = "company_id") %>%
  left_join(metab_per_sample, by = "company_id") %>%
  mutate(
    TrpIS_genera  = !is.na(n_g) & n_g > 0,
    TrpIS_protein = !is.na(n_p) & n_p > 0,
    TrpIS_metab   = !is.na(n_m) & n_m > 0
  ) %>% select(-n_g, -n_p, -n_m)

# =====================================================================
# Fig1A : Study design schematic
# =====================================================================
message("\n[Fig1A] Study design schematic ...")

n_per_window <- avail %>% count(time_window) %>%
  mutate(label = sprintf("%s\nn=%d", TIME_LABELS[as.character(time_window)], n))
tw_pos <- tibble(time_window = factor(TIME_LEVELS, levels = TIME_LEVELS),
                 x = c(0, 1, 1.5, 2.5, 5))
n_per_window <- n_per_window %>% left_join(tw_pos, by = "time_window")

layers_y <- tibble(
  layer = c("Clinical", "Renal function",
            "Metagenome", "Metaproteome", "Metabolome",
            "Trp-IS candidate genera",
            "Trp-IS protein modules",
            "Trp-IS metabolites"),
  y = 8:1
)

p1A <- ggplot() +
  geom_segment(data = tibble(x1 = min(n_per_window$x), x2 = max(n_per_window$x)),
               aes(x = x1, xend = x2, y = 2.2, yend = 2.2),
               linewidth = 0.35, color = "#888888") +
  geom_point(data = n_per_window,
             aes(x = x, y = 2.2, fill = time_window),
             shape = 21, size = 4.2, color = "white", stroke = 0.35) +
  geom_text(data = n_per_window,
            aes(x = x, y = 2.75, label = TIME_LABELS[as.character(time_window)]),
            size = 2.15, color = "#222222") +
  geom_text(data = n_per_window,
            aes(x = x, y = 1.62, label = paste0("n=", n)),
            size = 2.15, color = "#555555") +
  annotate("text", x = mean(range(n_per_window$x)), y = 0.62,
           label = "Metagenome  |  Metaproteome  |  Metabolome  |  Cr/CysC/eGFR",
           size = 2.25, color = "#333333") +
  scale_fill_manual(values = TIME_COLORS, guide = "none") +
  scale_x_continuous(limits = c(min(n_per_window$x) - 0.45, max(n_per_window$x) + 0.45)) +
  scale_y_continuous(limits = c(0.1, 3.1)) +
  labs(x = NULL, y = NULL, title = "Study design and sampling windows") +
  theme_nature_pub(7) +
  theme(panel.grid = element_blank(),
        axis.line = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(size = 8.5, face = "bold"))

save_fig_pdf(p1A, "Fig1A_TrpIS_study_design", width = 7.2, height = 2.0)

# =====================================================================
# Fig1B : Sample availability matrix (sorted by time_window then eGFR)
# =====================================================================
message("\n[Fig1B] Sample availability ordered by eGFR ...")

avail_sorted <- avail %>%
  arrange(time_window, egfr_ckdepi) %>%
  mutate(sample_order = row_number(),
         company_id = factor(company_id, levels = company_id))

avail_long <- avail_sorted %>%
  pivot_longer(c(Clinical, Renal, Metagenome, Metaproteome, Metabolome,
                 TrpIS_genera, TrpIS_protein, TrpIS_metab),
               names_to = "data_type", values_to = "available") %>%
  mutate(data_type = factor(data_type,
    levels = c("Clinical", "Renal", "Metagenome", "Metaproteome",
               "Metabolome", "TrpIS_genera", "TrpIS_protein", "TrpIS_metab"),
    labels = c("Clinical", "Renal function",
               "Metagenome", "Metaproteome", "Metabolome",
               "Trp-IS candidate genera",
               "Trp-IS protein modules",
               "Trp-IS metabolites")))

# Strip 1: time window
strip_tw <- ggplot(avail_sorted, aes(company_id, 1, fill = time_window)) +
  geom_tile(width = 1, height = 1) +
  scale_fill_manual(values = TIME_COLORS, labels = TIME_LABELS,
                    name = "Time window") +
  scale_x_discrete(expand = c(0, 0)) + scale_y_continuous(expand = c(0, 0)) +
  labs(x = NULL, y = NULL) +
  theme_nature_pub(7) +
  theme(axis.text = element_blank(), axis.ticks = element_blank(),
        axis.line = element_blank(), panel.grid = element_blank(),
        legend.position = "right",
        plot.margin = margin(2, 4, 0, 4))

# Strip 2: eGFR continuous
strip_egfr <- ggplot(avail_sorted, aes(company_id, 1, fill = egfr_ckdepi)) +
  geom_tile(width = 1, height = 1) +
  scale_fill_gradient(low = "#E45756", high = "#4C78A8",
                      na.value = "#E5E5E5", name = "eGFR") +
  scale_x_discrete(expand = c(0, 0)) + scale_y_continuous(expand = c(0, 0)) +
  labs(x = NULL, y = NULL) +
  theme_nature_pub(7) +
  theme(axis.text = element_blank(), axis.ticks = element_blank(),
        axis.line = element_blank(), panel.grid = element_blank(),
        legend.position = "right",
        plot.margin = margin(0, 4, 0, 4))

main_mat <- ggplot(avail_long,
                   aes(company_id, data_type, fill = available)) +
  geom_tile(color = "white", linewidth = 0.2) +
  scale_fill_manual(values = c(`TRUE` = "#4C78A8", `FALSE` = "#F0F0F0"),
                    guide = "none") +
  scale_x_discrete(expand = c(0, 0)) +
  scale_y_discrete(limits = rev, expand = c(0, 0)) +
  labs(x = "Samples (within each time window, sorted by eGFR low→high)",
       y = NULL) +
  theme_nature_pub(7) +
  theme(axis.line = element_blank(), axis.ticks.x = element_blank(),
        axis.text.x = element_blank(), panel.grid = element_blank(),
        plot.margin = margin(0, 4, 4, 4))

p1B <- strip_tw / strip_egfr / main_mat +
  plot_layout(heights = c(0.08, 0.08, 1))
save_fig_pdf(p1B, "Fig1B_TrpIS_sample_availability", width = 9.5, height = 3.2)
save_fig_data(avail_sorted, "Fig1B_sample_availability.csv")

# =====================================================================
# Fig1C : Available sample counts
# =====================================================================
message("\n[Fig1C] Sample counts ...")

count_set <- function(df, ...) {
  filt <- df %>% filter(...)
  nrow(filt)
}
counts <- tibble(
  set = factor(c("All samples",
                 "Metagenome + renal",
                 "Metaproteome + renal",
                 "Metabolome + renal",
                 "All 3 omics + renal",
                 "Post-Tx + 3 omics + renal"),
               levels = c("All samples",
                          "Metagenome + renal",
                          "Metaproteome + renal",
                          "Metabolome + renal",
                          "All 3 omics + renal",
                          "Post-Tx + 3 omics + renal")),
  n = c(
    nrow(avail),
    count_set(avail, Metagenome,   Renal),
    count_set(avail, Metaproteome, Renal),
    count_set(avail, Metabolome,   Renal),
    count_set(avail, Metagenome, Metaproteome, Metabolome, Renal),
    count_set(avail, Metagenome, Metaproteome, Metabolome, Renal,
              time_window != "Pre")
  )
)
save_fig_data(counts, "Fig1C_sample_counts.csv")

p1C <- ggplot(counts, aes(set, n)) +
  geom_col(fill = "#4C78A8", width = 0.55) +
  geom_text(aes(label = n), vjust = -0.3, size = 2.4, color = "#222222") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.20))) +
  labs(x = NULL, y = "n samples", title = "Analysable sample sets") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1))

save_fig_pdf(p1C, "Fig1C_TrpIS_sample_counts", width = 6.0, height = 3.0)

# =====================================================================
# Fig1D / E / F : Renal function distribution
# =====================================================================
message("\n[Fig1D-F] Renal function distributions ...")

renal_long <- clin %>%
  select(company_id, time_window,
         Cr = cr_umol_L, CysC = cysC_mg_L, eGFR = egfr_ckdepi) %>%
  pivot_longer(c(Cr, CysC, eGFR),
               names_to = "marker", values_to = "value") %>%
  filter(!is.na(value), !is.na(time_window))

# Per-marker stats
marker_stats <- renal_long %>%
  group_by(marker, time_window) %>%
  summarise(n     = n(),
            median = round(median(value, na.rm = TRUE), 3),
            q25   = round(quantile(value, 0.25, na.rm = TRUE), 3),
            q75   = round(quantile(value, 0.75, na.rm = TRUE), 3),
            .groups = "drop")

# Kruskal full + post-Tx only
kw_table <- bind_rows(
  renal_long %>% group_by(marker) %>%
    summarise(scope = "full",
              p = kruskal_p(value, time_window),
              .groups = "drop"),
  renal_long %>% filter(time_window != "Pre") %>%
    group_by(marker) %>%
    summarise(scope = "post_Tx_only",
              p = kruskal_p(value, droplevels(time_window)),
              .groups = "drop")
) %>%
  group_by(scope) %>%
  mutate(q = p.adjust(p, method = "BH")) %>% ungroup()

renal_summary <- marker_stats %>%
  left_join(kw_table %>% filter(scope == "full") %>%
              transmute(marker, kruskal_p_full = p, kruskal_q_full = q),
            by = "marker") %>%
  left_join(kw_table %>% filter(scope == "post_Tx_only") %>%
              transmute(marker, kruskal_p_postTx = p,
                        kruskal_q_postTx = q),
            by = "marker")
save_fig_data(renal_summary, "Fig1_renal_function_summary.csv")

draw_renal_panel <- function(marker_name, ylab_text, panel_letter) {
  d <- renal_long %>% filter(marker == marker_name)
  k_full  <- kw_table %>% filter(marker == marker_name, scope == "full")
  k_post  <- kw_table %>% filter(marker == marker_name, scope == "post_Tx_only")
  lab <- sprintf("Full p=%.3g; post-Tx p=%.3g",
                 k_full$p, k_post$p)
  ggplot(d, aes(time_window, value, fill = time_window)) +
    geom_boxplot(outlier.shape = NA, width = 0.55, alpha = 0.7,
                 linewidth = 0.3, color = "#333333") +
    geom_jitter(width = 0.18, size = 0.85, alpha = 0.65, color = "#444444") +
    annotate("text", x = -Inf, y = Inf, label = lab,
             hjust = -0.02, vjust = 1.35, size = 2.0, color = "#444444") +
    scale_fill_manual(values = TIME_COLORS, guide = "none") +
    scale_x_discrete(labels = TIME_LABELS) +
    labs(x = NULL, y = ylab_text, title = ylab_text) +
    theme_nature_pub(7) +
    theme(axis.text.x = element_text(angle = 30, hjust = 1))
}

p1D <- draw_renal_panel("Cr",   "Creatinine (µmol/L)",       "D") +
  scale_y_log10(labels = scales::label_number())
p1E <- draw_renal_panel("CysC", "Cystatin C (mg/L)",          "E") +
  scale_y_log10(labels = scales::label_number())
p1F <- draw_renal_panel("eGFR", "eGFR (mL/min/1.73 m²)",      "F")

save_fig_pdf(p1D, "Fig1D_Creatinine_distribution", width = 4.4, height = 3.0)
save_fig_pdf(p1E, "Fig1E_CystatinC_distribution",   width = 4.4, height = 3.0)
save_fig_pdf(p1F, "Fig1F_eGFR_distribution",        width = 4.4, height = 3.0)

# =====================================================================
# Combined Fig 1
# =====================================================================
message("\n[Fig1] Combined ...")

fig1 <- (p1A + labs(title = NULL) | p1C + labs(title = NULL)) /
        wrap_elements(p1B) /
        (p1D + labs(title = NULL) | p1E + labs(title = NULL) | p1F + labs(title = NULL)) +
        plot_layout(heights = c(0.55, 1.10, 1.25)) +
        plot_annotation(tag_levels = "A") &
        panel_tag_theme

save_fig_pdf(fig1, "Fig1_TrpIS_cohort_renal_gradient",
             width = 12.5, height = 8.2)

message("\nFig1 (Trp-IS cohort) complete.\n")
