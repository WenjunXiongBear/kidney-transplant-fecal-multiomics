# =====================================================================
# 11_Fig3_TrpIS_module_ranking.R
# Trp-IS module ranking among all functional modules.
# =====================================================================

source("R/setup.R")



# ---------------------------------------------------------------------
# Local Nature-like visual system override (format-only; data/statistics unchanged)
# ---------------------------------------------------------------------
# Keep the analysis unchanged. This block only standardizes typography, borders,
# and a cleaner low-saturation palette across all figures.
TIME_COLORS <- setNames(c("#8A8A8A", "#4C78A8", "#72B7B2", "#F2CF5B", "#E45756"),
                        TIME_LEVELS)
RENAL_GROUP_COLORS <- c("Low eGFR" = "#E45756",
                        "Mid eGFR" = "#F2CF5B",
                        "High eGFR" = "#4C78A8")
LAYER_COLORS <- c("Genus" = "#4C78A8",
                  "Protein" = "#72B7B2",
                  "Metabolite" = "#F2CF5B",
                  "Renal" = "#E45756",
                  "Integrated" = "#B279A2",
                  "Score" = "#B279A2")
HEATMAP_LOW  <- "#4C78A8"
HEATMAP_MID  <- "#FFFFFF"
HEATMAP_HIGH <- "#E45756"
TEXT_COL <- "#222222"
AXIS_COL <- "#333333"
GRID_COL <- "#ECECEC"
BORDER_COL <- "#333333"

nature_panel <- theme(
  panel.border = element_rect(color = BORDER_COL, fill = NA, linewidth = 0.35),
  plot.title = element_text(face = "bold", color = TEXT_COL),
  axis.title = element_text(face = "bold", color = TEXT_COL),
  strip.text = element_text(face = "bold", color = TEXT_COL)
)

theme_nature_pub <- function(base_size = 7, base_family = "Helvetica") {
  base_size <- max(base_size, 8)
  theme_classic(base_size = base_size, base_family = base_family) %+replace%
    theme(
      text = element_text(color = TEXT_COL),
      plot.title = element_text(size = base_size + 1.2, face = "bold", hjust = 0, color = TEXT_COL),
      axis.title = element_text(size = base_size, face = "bold", color = TEXT_COL),
      axis.text = element_text(size = base_size - 1, color = "#333333"),
      axis.line = element_line(color = AXIS_COL, linewidth = 0.32),
      axis.ticks = element_line(color = AXIS_COL, linewidth = 0.28),
      axis.ticks.length = unit(1.5, "mm"),
      panel.border = element_rect(color = BORDER_COL, fill = NA, linewidth = 0.35),
      panel.grid.major.y = element_line(color = GRID_COL, linewidth = 0.25),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", color = TEXT_COL),
      legend.title = element_text(size = base_size - 1, face = "bold", color = TEXT_COL),
      legend.text = element_text(size = base_size - 1, color = "#333333"),
      legend.key.height = unit(3.8, "mm"),
      legend.key.width = unit(4.4, "mm"),
      plot.margin = margin(5, 5, 5, 5)
    )
}

panel_tag_theme <- theme(plot.tag = element_text(face = "bold", size = 12, color = TEXT_COL),
                         plot.tag.position = c(0.01, 0.99))



master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
clin      <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
prot_anno <- readRDS(file.path(PROC_DIR, "metaprot_annotation.rds"))
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
metab_feat<- read_csv(file.path(PROC_DIR, "metab_features.csv"),
                      show_col_types = FALSE)

prot_pass <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)

# ---------------------------------------------------------------------
# Step 1: Build functional modules (KO + keyword)
# ---------------------------------------------------------------------
# Each module = list(kos = ..., kw = regex against ko_definition)
modules_def <- list(
  TrpIS_indole = list(
    kos = c("K01667", "K00179", "K00180", "K01695", "K01696"),
    kw  = "tryptophan|indole|tryptophanase|indolepyruvate"
  ),
  Kynurenine_pathway = list(
    kos = c("K00466", "K01556", "K01432", "K00816"),
    kw  = "kynurenine|kynureninase|kmo"
  ),
  pCresol_aromatic = list(
    kos = c("K22354", "K22355", "K22356", "K01692",
            "K05359", "K00822", "K01657"),
    kw  = "p-cresol|p-hydroxyphenylacetate|tyrosine ammonia|tyrosine phenol"
  ),
  SCFA_related = list(
    kos = c("K00925", "K00929", "K01034", "K01035", "K00248", "K01034"),
    kw  = "butyrate|butyryl|propionate|acetate kinase|acetyl-CoA|short-chain"
  ),
  Bile_acid = list(
    kos = c("K01442", "K07007"),
    kw  = "bile acid|cholate|deoxycholate|bsh|bile salt"
  ),
  AA_metabolism = list(
    kos = NULL,
    kw  = "amino acid|alanine|arginine|aspartate|glutamate|histidine|leucine|lysine|methionine|phenylalanine|proline|serine|threonine|valine"
  ),
  Carbohydrate_metab = list(
    kos = NULL,
    kw  = "glycolysis|pyruvate|fructose|galactose|maltose|carbohydrate|glucose"
  ),
  Energy_metab = list(
    kos = NULL,
    kw  = "ATP synthase|cytochrome|NADH|electron transport|TCA|citrate cycle|oxidative phosphorylation"
  ),
  Stress_transport = list(
    kos = NULL,
    kw  = "ABC transporter|chaperone|heat shock|oxidative stress|osmotic stress|hsp"
  )
)

# Match each protein to one or more modules
prot_module_long <- map_dfr(names(modules_def), function(mod) {
  spec <- modules_def[[mod]]
  hit <- prot_anno %>%
    filter((!is.null(spec$kos) & KO_id %in% spec$kos) |
           (!is.null(spec$kw)  & grepl(spec$kw, ko_definition,
                                       ignore.case = TRUE))) %>%
    select(protein_id, KO_id, ko_definition, Taxonomy_genus,
           Taxonomy_species)
  if (nrow(hit) == 0) return(NULL)
  hit %>% mutate(module = mod)
}) %>%
  distinct(protein_id, module, .keep_all = TRUE)

save_fig_data(prot_module_long %>%
                rename(KO = KO_id, description = ko_definition,
                       genus = Taxonomy_genus, species = Taxonomy_species,
                       module_name = module),
              "Fig3_module_members.csv")

# Per-sample module abundance (sum of member protein abundance)
mod_per_sample <- metaprot %>%
  filter(company_id %in% prot_pass) %>%
  inner_join(prot_module_long %>% select(protein_id, module),
             by = "protein_id") %>%
  group_by(company_id, module) %>%
  summarise(abund = sum(abundance, na.rm = TRUE), .groups = "drop")

mod_wide <- mod_per_sample %>%
  pivot_wider(names_from = module, values_from = abund, values_fill = 0)
mod_mat <- as.matrix(mod_wide %>% select(-company_id))
rownames(mod_mat) <- mod_wide$company_id
mod_mat_log <- log2(mod_mat + 1)

# =====================================================================
# Helpers (correlation + adjustment)
# =====================================================================
spearman_test <- function(x, y) {
  ok <- complete.cases(x, y)
  if (sum(ok) < 8) return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  rs <- suppressWarnings(cor.test(x[ok], y[ok], method = "spearman",
                                  exact = FALSE))
  c(rho = unname(rs$estimate), p = rs$p.value, n = sum(ok))
}
partial_lm_tw <- function(x, y, tw) {
  ok <- complete.cases(x, y, tw)
  if (sum(ok) < 10) return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  fit <- lm(rank(y[ok]) ~ rank(x[ok]) + factor(tw[ok]))
  cc <- summary(fit)$coefficients
  if (!"rank(x[ok])" %in% rownames(cc))
    return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  t  <- cc["rank(x[ok])", "t value"]; p <- cc["rank(x[ok])", "Pr(>|t|)"]
  df <- summary(fit)$df[2]
  rho <- sign(t) * sqrt(t^2 / (t^2 + df))
  c(rho = rho, p = p, n = sum(ok))
}

clin_lookup <- clin %>%
  select(company_id, time_window,
         Cr = cr_umol_L, CysC = cysC_mg_L, eGFR = egfr_ckdepi)

# Module × clinical association table (raw + adjusted + post-Tx)
mod_clin_long <- list()
for (mod in colnames(mod_mat_log)) {
  for (idx in c("Cr", "CysC", "eGFR")) {
    common <- intersect(rownames(mod_mat_log), clin_lookup$company_id)
    x <- mod_mat_log[common, mod]
    y <- setNames(clin_lookup[[idx]],          clin_lookup$company_id)[common]
    tw <- setNames(as.character(clin_lookup$time_window),
                   clin_lookup$company_id)[common]
    raw <- spearman_test(x, y)
    adj <- partial_lm_tw(x, y, tw)
    # post-Tx only
    keep_post <- tw != "Pre"
    post <- spearman_test(x[keep_post], y[keep_post])
    mod_clin_long[[length(mod_clin_long) + 1]] <- tibble(
      module = mod, clinical_index = idx,
      raw_rho = raw["rho"], raw_p = raw["p"], raw_n = raw["n"],
      adj_rho = adj["rho"], adj_p = adj["p"], adj_n = adj["n"],
      post_rho = post["rho"], post_p = post["p"], post_n = post["n"]
    )
  }
}
mod_clin_df <- bind_rows(mod_clin_long) %>%
  group_by(clinical_index) %>%
  mutate(raw_q  = p.adjust(raw_p,  method = "BH"),
         adj_q  = p.adjust(adj_p,  method = "BH"),
         post_q = p.adjust(post_p, method = "BH")) %>%
  ungroup()

save_fig_data(mod_clin_df, "Fig3A_module_clinical_results.csv")

# =====================================================================
# Fig3A : Module × clinical heatmap
# =====================================================================
message("\n[Fig3A] Module heatmap ...")

heat_df <- mod_clin_df %>%
  mutate(label = paste0(
    ifelse(raw_q < 0.05, "*", ifelse(raw_q < 0.10, "·", "")),
    ifelse(adj_q < 0.05, "†", ifelse(adj_q < 0.10, "‡", ""))
  )) %>%
  mutate(module = factor(module, levels = names(modules_def)),
         clinical_index = factor(clinical_index,
                                 levels = c("Cr", "CysC", "eGFR")))

p3A <- ggplot(heat_df, aes(clinical_index, module, fill = raw_rho)) +
  geom_tile(color = "white", linewidth = 0.4) +
  geom_text(aes(label = sprintf("%.2f%s", raw_rho, label)),
            size = 2.1, color = "#222222") +
  scale_fill_gradient2(low = HEATMAP_LOW, mid = HEATMAP_MID,
                       high = HEATMAP_HIGH, midpoint = 0,
                       limits = c(-1, 1), name = "Spearman ρ") +
  scale_y_discrete(limits = rev) +
  labs(x = NULL, y = NULL,
       title = "Module associations with renal indices") +
  theme_nature_pub(7) +
  theme(panel.grid = element_blank(), axis.line = element_blank(),
        axis.text.x = element_text(face = "bold"))

save_fig_pdf(p3A, "Fig3A_module_clinical_heatmap", width = 5.6, height = 4.2)

# =====================================================================
# Fig3B : Trp-IS module ranking
# =====================================================================
message("\n[Fig3B] Module ranking ...")

rank_df <- mod_clin_df %>%
  filter(clinical_index == "eGFR") %>%
  arrange(desc(abs(raw_rho))) %>%
  mutate(rank = row_number(),
         is_trpIS = module %in% c("TrpIS_indole", "Kynurenine_pathway"),
         module = factor(module, levels = module))

save_fig_data(rank_df, "Fig3B_module_ranking.csv")

p3B <- ggplot(rank_df, aes(reorder(module, abs(raw_rho)),
                           abs(raw_rho), color = is_trpIS)) +
  geom_segment(aes(xend = module, y = 0, yend = abs(raw_rho)),
               linewidth = 0.4) +
  geom_point(size = 2.5) +
  geom_text(aes(label = sprintf("q=%.3f", raw_q)),
            hjust = -0.1, size = 2.0, color = "#444444") +
  scale_color_manual(values = c(`TRUE` = "#E45756", `FALSE` = "#999999"),
                     labels = c("Other", "Trp-IS / Kyn"),
                     name = NULL) +
  scale_y_continuous(limits = c(0, max(abs(rank_df$raw_rho)) * 1.4)) +
  coord_flip() +
  labs(x = NULL, y = "|Spearman ρ| with eGFR (raw)",
       title = "Module ranking by |ρ| with eGFR") +
  theme_nature_pub(7) +
  theme(legend.position = "right")

save_fig_pdf(p3B, "Fig3B_TrpIS_module_ranking", width = 6.0, height = 3.8)

# =====================================================================
# Step 2: Build Trp-IS scores at 3 layers + integrated
# =====================================================================
message("\n[Fig3C/D] Building Trp-IS layer scores ...")

# Genus layer score (sum of z-scored relative abundances)
trp_genera <- c("Bacteroides", "Alistipes", "Escherichia", "Fusobacterium")
genus_w <- genus %>% filter(genus %in% trp_genera) %>%
  pivot_wider(names_from = genus, values_from = rel_abund, values_fill = 0)
genus_mat_trp <- as.matrix(genus_w %>% select(-company_id))
rownames(genus_mat_trp) <- genus_w$company_id
genus_z <- scale(log10(genus_mat_trp + 1e-6))
TrpIS_genus_score <- rowMeans(genus_z, na.rm = TRUE)

# Protein layer score (sum of z-scored module abundances for Trp-IS modules)
trpIS_modules <- c("TrpIS_indole", "Kynurenine_pathway")
have_mods <- intersect(trpIS_modules, colnames(mod_mat_log))
if (length(have_mods) > 0) {
  prot_z <- scale(mod_mat_log[, have_mods, drop = FALSE])
  TrpIS_protein_score <- rowMeans(prot_z, na.rm = TRUE)
} else {
  TrpIS_protein_score <- setNames(rep(NA_real_, nrow(mod_mat_log)),
                                  rownames(mod_mat_log))
}

# Metabolite layer score
trp_metab_kw <- c(
  Tryptophan = "^L-Tryptophan$|^Tryptophan$",
  Indole     = "^Indole$",
  IS         = "Indoxyl sulph|Indoxyl sulf",
  IAA        = "Indole-3-acetic|Indoleacetic",
  Kynurenine = "^L-Kynurenine$|^Kynurenine$",
  KynA       = "Kynurenic acid"
)
trp_metab_ids <- map_chr(trp_metab_kw, function(p) {
  hit <- metab_feat %>%
    filter(grepl(p, Name, ignore.case = TRUE),
           Level %in% c("level1", "level2"))
  if (nrow(hit) == 0) NA_character_ else hit$metabolite_id[1]
})
metab_w <- metab %>%
  filter(metabolite_id %in% trp_metab_ids[!is.na(trp_metab_ids)]) %>%
  pivot_wider(names_from = metabolite_id, values_from = value,
              values_fill = NA)
metab_mat_trp <- as.matrix(metab_w %>% select(-company_id))
rownames(metab_mat_trp) <- metab_w$company_id
metab_mat_trp[is.na(metab_mat_trp)] <- 0
metab_z <- scale(log2(metab_mat_trp + 1))
TrpIS_metab_score <- rowMeans(metab_z, na.rm = TRUE)

# Integrate across the 3 layers (mean of available layer scores per sample)
all_ids <- master$company_id
score_df <- tibble(
  company_id = all_ids,
  TrpIS_genus_score   = TrpIS_genus_score[match(all_ids, names(TrpIS_genus_score))],
  TrpIS_protein_score = TrpIS_protein_score[match(all_ids, names(TrpIS_protein_score))],
  TrpIS_metab_score   = TrpIS_metab_score[match(all_ids, names(TrpIS_metab_score))]
) %>%
  rowwise() %>%
  mutate(TrpIS_integrated_score = mean(c(TrpIS_genus_score,
                                          TrpIS_protein_score,
                                          TrpIS_metab_score), na.rm = TRUE)) %>%
  ungroup() %>%
  mutate(TrpIS_integrated_score = ifelse(is.nan(TrpIS_integrated_score),
                                          NA_real_, TrpIS_integrated_score)) %>%
  inner_join(clin_lookup, by = "company_id")

# Save scores for downstream Fig4-5
save_fig_data(score_df, "Fig3_TrpIS_layer_scores.csv")
saveRDS(score_df, file.path(PROC_DIR, "TrpIS_layer_scores.rds"))

# =====================================================================
# Fig3C : Trp-IS scores across eGFR tertiles
# =====================================================================
message("\n[Fig3C] eGFR tertile boxplots ...")

score_tert <- score_df %>% filter(!is.na(eGFR)) %>%
  mutate(eGFR_tertile = cut(eGFR, breaks = quantile(eGFR, probs = c(0, 1/3, 2/3, 1),
                                                    na.rm = TRUE),
                            include.lowest = TRUE,
                            labels = c("Low eGFR", "Mid eGFR", "High eGFR")))

score_long <- score_tert %>%
  pivot_longer(c(TrpIS_genus_score, TrpIS_protein_score,
                 TrpIS_metab_score, TrpIS_integrated_score),
               names_to = "score_type", values_to = "score") %>%
  filter(!is.na(score)) %>%
  mutate(score_type = factor(score_type,
    levels = c("TrpIS_genus_score","TrpIS_protein_score",
               "TrpIS_metab_score","TrpIS_integrated_score"),
    labels = c("Genus score","Protein score","Metabolite score","Integrated")))

# Stats per score
score_stats <- score_long %>% group_by(score_type) %>%
  summarise(
    kruskal_p = suppressWarnings(kruskal.test(score ~ eGFR_tertile)$p.value),
    trend_p   = suppressWarnings(cor.test(score, as.numeric(eGFR_tertile),
                                          method = "spearman",
                                          exact = FALSE)$p.value),
    .groups = "drop") %>%
  mutate(kruskal_q = p.adjust(kruskal_p, method = "BH"),
         label = sprintf("KW q=%.3f, trend p=%.3f", kruskal_q, trend_p))
save_fig_data(score_stats, "Fig3C_TrpIS_score_group_stats.csv")

p3C <- ggplot(score_long, aes(eGFR_tertile, score, fill = eGFR_tertile)) +
  geom_boxplot(outlier.shape = NA, width = 0.55, alpha = 0.7,
               linewidth = 0.3, color = "#333333") +
  geom_jitter(width = 0.18, size = 0.85, alpha = 0.65, color = "#444444") +
  geom_text(data = score_stats,
            aes(x = -Inf, y = Inf, label = label),
            inherit.aes = FALSE,
            hjust = -0.05, vjust = 1.4, size = 2.0, color = "#444444") +
  facet_wrap(~ score_type, scales = "free_y", nrow = 1) +
  scale_fill_manual(values = RENAL_GROUP_COLORS, guide = "none") +
  labs(x = NULL, y = "Trp-IS layer score (z-scored)",
       title = "Trp-IS layer scores across eGFR tertiles") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))

save_fig_pdf(p3C, "Fig3C_TrpIS_score_eGFR_groups", width = 9.5, height = 3.0)

# =====================================================================
# Fig3D : Trp-IS score vs eGFR scatter
# =====================================================================
message("\n[Fig3D] Score vs eGFR scatter ...")

score_panel <- score_df %>%
  pivot_longer(c(TrpIS_protein_score, TrpIS_metab_score,
                 TrpIS_integrated_score),
               names_to = "score_type", values_to = "score") %>%
  filter(!is.na(score), !is.na(eGFR)) %>%
  mutate(score_type = factor(score_type,
    levels = c("TrpIS_protein_score","TrpIS_metab_score","TrpIS_integrated_score"),
    labels = c("Protein score","Metabolite score","Integrated")))

# Compute stats per score: raw + adjusted + post-Tx
score_corr_stats <- score_panel %>%
  group_by(score_type) %>%
  group_modify(~ {
    x <- .x$score; y <- .x$eGFR; tw <- as.character(.x$time_window)
    raw  <- spearman_test(x, y)
    adj  <- partial_lm_tw(x, y, tw)
    keep_post <- tw != "Pre"
    post <- spearman_test(x[keep_post], y[keep_post])
    tibble(raw_rho = raw["rho"], raw_p = raw["p"], n_total = raw["n"],
           adj_rho = adj["rho"], adj_p = adj["p"],
           post_rho = post["rho"], post_p = post["p"], n_post = post["n"])
  }) %>%
  ungroup() %>%
  mutate(raw_q  = p.adjust(raw_p,  method = "BH"),
         adj_q  = p.adjust(adj_p,  method = "BH"),
         post_q = p.adjust(post_p, method = "BH"),
         text = sprintf("raw ρ=%.2f q=%.3f | adj p=%.3f | post p=%.3f, n=%d",
                        raw_rho, raw_q, adj_p, post_p, n_total))
save_fig_data(score_corr_stats, "Fig3D_TrpIS_score_correlation.csv")

p3D <- ggplot(score_panel, aes(score, eGFR, color = time_window)) +
  geom_smooth(aes(group = 1), method = "lm", formula = y ~ x,
              color = "#666666", linetype = "dashed",
              linewidth = 0.4, se = FALSE) +
  geom_point(size = 1.4, alpha = 0.85) +
  geom_text(data = score_corr_stats,
            aes(x = -Inf, y = Inf, label = text),
            inherit.aes = FALSE,
            hjust = -0.02, vjust = 1.4, size = 2.0, color = "#444444") +
  scale_color_manual(values = TIME_COLORS, labels = TIME_LABELS,
                     name = "Time window") +
  facet_wrap(~ score_type, scales = "free_x", nrow = 1) +
  labs(x = "Trp-IS score (z-scored)",
       y = "eGFR (mL/min/1.73 m²)",
       title = "Trp-IS scores vs eGFR") +
  theme_nature_pub(7)

save_fig_pdf(p3D, "Fig3D_TrpIS_score_vs_eGFR", width = 10.5, height = 3.4)

# =====================================================================
# Combined Fig 3
# =====================================================================
message("\n[Fig3] Combined ...")

fig3 <- (p3D + labs(title = NULL)) /
        (p3A + labs(title = NULL) | p3B + labs(title = NULL)) /
        (p3C + labs(title = NULL)) +
        plot_layout(heights = c(1.25, 1.0, 1.05)) +
        plot_annotation(tag_levels = "A") &
        panel_tag_theme

save_fig_pdf(fig3, "Fig3_TrpIS_module_ranking", width = 12.5, height = 8.8)

message("\nFig3 (module ranking) complete.\n")
