# =====================================================================
# 14_FigS1_QC_metrics.R
# Supplementary Figure S1 — Per-sample quality control across three
# omic layers and pooled QC-sample stability for the metabolomic run.
# =====================================================================

source("R/setup.R")

master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))

# ---------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------
genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
metab_feat<- read_csv(file.path(PROC_DIR, "metab_features.csv"),
                      show_col_types = FALSE)

# Optional pre-computed company-side basic_stat for proteomics
basic_stat_path <- file.path(RAW_DIR, "basic_stat.txt")
qc_cv_path      <- file.path(RAW_DIR, "QC_CV.xls")
qc_pca_path     <- file.path(RAW_DIR, "QC-PCAscores.xls")

# =====================================================================
# Per-sample summary metrics
# =====================================================================

# Metagenomic depth proxy = number of detected genera with rel_abund > 0
qc_metag <- genus %>%
  group_by(company_id) %>%
  summarise(n_genera_detected = sum(rel_abund > 0, na.rm = TRUE),
            shannon = -sum(rel_abund * log(pmax(rel_abund, 1e-12)),
                           na.rm = TRUE),
            .groups = "drop")

# Metaproteomic depth = number of distinct proteins quantified per sample
qc_metaprot <- metaprot %>%
  group_by(company_id) %>%
  summarise(n_proteins_quantified = sum(abundance > 0, na.rm = TRUE),
            .groups = "drop")

# Metabolomic depth = features per sample, split by HMDB confidence level
metab_level_lookup <- metab_feat %>% select(metabolite_id, Level)
qc_metab_long <- metab %>%
  inner_join(metab_level_lookup, by = "metabolite_id") %>%
  filter(!is.na(value), value > 0) %>%
  group_by(company_id, Level) %>%
  summarise(n_features = n(), .groups = "drop")

qc_metab_wide <- qc_metab_long %>%
  pivot_wider(names_from = Level, values_from = n_features,
              names_prefix = "n_metab_",
              values_fill = 0)

qc_table <- master %>%
  select(company_id, time_window) %>%
  left_join(qc_metag,     by = "company_id") %>%
  left_join(qc_metaprot,  by = "company_id") %>%
  left_join(qc_metab_wide, by = "company_id")

save_fig_data(qc_table, "FigS1_per_sample_QC_metrics.csv")

# =====================================================================
# Fig S1A : Metagenomic depth (genera detected) per sample
# =====================================================================
message("\n[FigS1A] Metagenomic depth ...")

pS1A <- ggplot(qc_table,
               aes(reorder(company_id, n_genera_detected),
                   n_genera_detected, fill = time_window)) +
  geom_col(width = 0.75, color = "grey25", linewidth = 0.15) +
  scale_fill_manual(values = TIME_COLORS, labels = TIME_LABELS,
                    name = "Time window") +
  labs(x = NULL, y = "Genera detected (rel. abund. > 0)",
       title = "A  Metagenomic depth per sample") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5,
                                   hjust = 1, size = 5))

save_fig_pdf(pS1A, "FigS1A_metag_depth", width = 7, height = 3.2)

# =====================================================================
# Fig S1B : Metaproteomic depth (proteins quantified) per sample
# =====================================================================
message("\n[FigS1B] Metaproteomic depth ...")

pS1B <- ggplot(qc_table %>% filter(!is.na(n_proteins_quantified)),
               aes(reorder(company_id, n_proteins_quantified),
                   n_proteins_quantified, fill = time_window)) +
  geom_col(width = 0.75, color = "grey25", linewidth = 0.15) +
  scale_fill_manual(values = TIME_COLORS, labels = TIME_LABELS,
                    name = "Time window") +
  labs(x = NULL, y = "Proteins quantified",
       title = "B  Metaproteomic depth per sample") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5,
                                   hjust = 1, size = 5))

save_fig_pdf(pS1B, "FigS1B_metaprot_depth", width = 7, height = 3.2)

# =====================================================================
# Fig S1C : Metabolomic depth by confidence level per sample
# =====================================================================
message("\n[FigS1C] Metabolomic depth ...")

metab_long <- qc_table %>%
  select(company_id, time_window, starts_with("n_metab_")) %>%
  pivot_longer(cols = starts_with("n_metab_"),
               names_to = "Level", values_to = "n_features") %>%
  mutate(Level = sub("n_metab_", "", Level),
         Level = factor(Level, levels = c("level1", "level2", "level3"),
                        labels = c("Level 1", "Level 2", "Level 3")))

pS1C <- ggplot(metab_long, aes(reorder(company_id, n_features),
                                n_features, fill = Level)) +
  geom_col(position = "stack", width = 0.75,
           color = "grey30", linewidth = 0.15) +
  scale_fill_manual(values = c("Level 1" = "#5E81AC",
                                "Level 2" = "#88C0D0",
                                "Level 3" = "#D8DEE9"),
                    name = "HMDB confidence") +
  labs(x = NULL, y = "Annotated metabolic features",
       title = "C  Metabolomic depth per sample, by HMDB confidence level") +
  theme_nature_pub(7) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5,
                                   hjust = 1, size = 5))

save_fig_pdf(pS1C, "FigS1C_metab_depth", width = 7, height = 3.5)

# =====================================================================
# Fig S1D : Metabolomic feature detection rate by confidence level
# =====================================================================
message("\n[FigS1D] Metabolomic feature detection rate ...")

metab_detection <- metab %>%
  inner_join(metab_level_lookup, by = "metabolite_id") %>%
  group_by(metabolite_id, Level) %>%
  summarise(
    n_samples = n_distinct(company_id),
    n_detected = sum(!is.na(value) & value > 0, na.rm = TRUE),
    detection_rate = n_detected / n_samples,
    missing_rate = 1 - detection_rate,
    .groups = "drop"
  ) %>%
  mutate(
    Level = sub("n_metab_", "", Level),
    Level = factor(Level,
                   levels = c("level1", "level2", "level3"),
                   labels = c("Level 1", "Level 2", "Level 3"))
  ) %>%
  filter(!is.na(Level))

save_fig_data(metab_detection, "FigS1D_metabolomic_feature_detection.csv")

pS1D <- ggplot(metab_detection,
               aes(Level, detection_rate, fill = Level)) +
  geom_violin(width = 0.78, trim = TRUE,
              color = "#333333", linewidth = 0.25, alpha = 0.75) +
  geom_boxplot(width = 0.18, outlier.size = 0.4,
               color = "#333333", linewidth = 0.25, alpha = 0.95) +
  scale_fill_manual(values = c("Level 1" = "#5E81AC",
                               "Level 2" = "#88C0D0",
                               "Level 3" = "#D8DEE9"),
                    guide = "none") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1),
                     limits = c(0, 1),
                     expand = expansion(mult = c(0, 0.05))) +
  labs(x = NULL,
       y = "Detection rate across samples",
       title = "D  Metabolomic feature detection rate by confidence level") +
  theme_nature_pub(7)

save_fig_pdf(pS1D, "FigS1D_metabolomic_feature_detection", width = 5, height = 3.0)

# =====================================================================
# Fig S1E : Cross-omic sample-level QC summary
# =====================================================================
message("\n[FigS1E] Cross-omic sample-level QC summary ...")

qc_scaled <- qc_table %>%
  mutate(
    n_metab_total = rowSums(as.data.frame(select(., starts_with("n_metab_"))),
                            na.rm = TRUE)
  ) %>%
  select(company_id, time_window,
         n_genera_detected,
         n_proteins_quantified,
         n_metab_total) %>%
  mutate(
    sample_order = row_number(),
    time_window = factor(time_window, levels = TIME_LEVELS)
  ) %>%
  pivot_longer(
    cols = c(n_genera_detected, n_proteins_quantified, n_metab_total),
    names_to = "qc_metric",
    values_to = "value"
  ) %>%
  mutate(
    qc_metric = recode(qc_metric,
                       "n_genera_detected" = "Metagenome\ngenera",
                       "n_proteins_quantified" = "Metaproteome\nproteins",
                       "n_metab_total" = "Metabolome\nfeatures")
  ) %>%
  group_by(qc_metric) %>%
  mutate(z_value = as.numeric(scale(value))) %>%
  ungroup()

save_fig_data(qc_scaled, "FigS1E_cross_omic_QC_summary.csv")

pS1E <- ggplot(qc_scaled,
               aes(x = factor(sample_order),
                   y = qc_metric,
                   fill = z_value)) +
  geom_tile(color = "white", linewidth = 0.15) +
  scale_fill_gradient2(low = "#5E81AC",
                       mid = "#F7F7F7",
                       high = "#BF616A",
                       midpoint = 0,
                       na.value = "#E5E5E5",
                       name = "Scaled\nQC metric") +
  scale_x_discrete(breaks = NULL) +
  labs(x = "Samples ordered by metadata table",
       y = NULL,
       title = "E  Cross-omic sample-level QC summary") +
  theme_nature_pub(7) +
  theme(
    panel.grid = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y = element_text(face = "bold")
  )

save_fig_pdf(pS1E, "FigS1E_cross_omic_QC_summary", width = 5, height = 3.5)
# =====================================================================
# Combined Fig S1
# =====================================================================
message("\n[FigS1] Combined ...")

figS1 <- (pS1A + labs(title = NULL)) /
         (pS1B + labs(title = NULL)) /
         (pS1C + labs(title = NULL)) +
  plot_layout(heights = c(1, 1, 1)) +
  plot_annotation(tag_levels = list(c("A", "B", "C"))) &
  theme(plot.tag = element_text(face = "bold", size = 11))

save_fig_pdf(figS1, "FigS1_QC_metrics", width = 11, height = 10)

save_fig_pdf(figS1, "FigS1_QC_metrics", width = 11, height = 14)
message("\nFig S1 complete.\n")
