# =====================================================================
# 15_FigS2_extended_PCA.R
# Supplementary Figure S2 — Extended per-layer ordination and PERMANOVA
# decomposition across time window and additional clinical covariates.
# =====================================================================

source("R/setup.R")
suppressPackageStartupMessages({
  library(vegan)
  library(ape)
})

master <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                   show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
clin   <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                   show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))

genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)

prot_pass <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)

# =====================================================================
# Build per-sample wide matrices and prevalence filtering
# =====================================================================

mat_genus <- genus %>%
  filter(rel_abund > 0) %>%
  pivot_wider(names_from = genus, values_from = rel_abund, values_fill = 0)
mat_genus_m <- as.matrix(mat_genus[, -1]); rownames(mat_genus_m) <- mat_genus$company_id
keep_g <- (colSums(mat_genus_m > 0) >= 0.20 * nrow(mat_genus_m)) &
          (colMeans(mat_genus_m) >= 1e-4)
mat_genus_m <- mat_genus_m[, keep_g]

mat_prot <- metaprot %>%
  filter(company_id %in% prot_pass) %>%
  pivot_wider(names_from = protein_id, values_from = abundance,
              values_fill = 0)
mat_prot_m <- as.matrix(mat_prot[, -1]); rownames(mat_prot_m) <- mat_prot$company_id
keep_p <- colSums(mat_prot_m > 0) >= 0.50 * nrow(mat_prot_m)
mat_prot_m <- log2(mat_prot_m[, keep_p] + 1)

mat_metab <- metab %>%
  pivot_wider(names_from = metabolite_id, values_from = value,
              values_fill = 0)
mat_metab_m <- as.matrix(mat_metab[, -1]); rownames(mat_metab_m) <- mat_metab$company_id
keep_m <- colMeans(!is.na(mat_metab_m) & mat_metab_m > 0) >= 0.70
mat_metab_m <- log2(mat_metab_m[, keep_m] + 1)

# =====================================================================
# Ordination helper
# =====================================================================
ordinate_layer <- function(mat, layer_name, distance_method) {
  if (distance_method == "bray") {
    d <- vegdist(mat, method = "bray")
    pco <- ape::pcoa(d)
    coords <- as.data.frame(pco$vectors[, 1:2])
    names(coords) <- c("Dim1", "Dim2")
    coords$company_id <- rownames(coords)
    pct <- round(100 * pco$values$Relative_eig[1:2], 1)
    list(coords = coords, pct = pct, dist = d)
  } else {
    pca <- prcomp(mat, scale. = TRUE, center = TRUE)
    coords <- as.data.frame(pca$x[, 1:2])
    names(coords) <- c("Dim1", "Dim2")
    coords$company_id <- rownames(coords)
    pct <- round(100 * (pca$sdev^2 / sum(pca$sdev^2))[1:2], 1)
    list(coords = coords, pct = pct,
         dist = dist(scale(mat)))
  }
}

layers <- list(
  Genus      = list(mat = mat_genus_m, method = "bray",
                    title = "A  Metagenomic genus, Bray-Curtis PCoA"),
  Protein    = list(mat = mat_prot_m,  method = "euclidean",
                    title = "B  Metaproteomic, PCA on log2 abundance"),
  Metabolite = list(mat = mat_metab_m, method = "euclidean",
                    title = "C  Metabolomic, PCA on log2 intensity")
)

ord_results <- lapply(layers, function(L) {
  ordinate_layer(L$mat, layer_name = names(L), distance_method = L$method)
})

# =====================================================================
# Figs S2A / S2B / S2C : per-layer ordination
# =====================================================================
plot_ordination <- function(ord, title) {
  d <- ord$coords %>%
    inner_join(master %>% select(company_id, time_window),
               by = "company_id")
  ggplot(d, aes(Dim1, Dim2, color = time_window, fill = time_window)) +
    stat_ellipse(geom = "polygon", alpha = 0.10, linewidth = 0.3) +
    geom_point(size = 1.8, alpha = 0.9, stroke = 0) +
    scale_color_manual(values = TIME_COLORS, labels = TIME_LABELS,
                       name = "Time window") +
    scale_fill_manual(values  = TIME_COLORS, labels = TIME_LABELS,
                      guide = "none") +
    labs(x = sprintf("Dim 1 (%.1f%%)", ord$pct[1]),
         y = sprintf("Dim 2 (%.1f%%)", ord$pct[2]),
         title = title) +
    theme_nature_pub(7)
}

pS2A <- plot_ordination(ord_results$Genus,      layers$Genus$title)
pS2B <- plot_ordination(ord_results$Protein,    layers$Protein$title)
pS2C <- plot_ordination(ord_results$Metabolite, layers$Metabolite$title)

save_fig_pdf(pS2A, "FigS2A_genus_PCoA",   width = 5, height = 4)
save_fig_pdf(pS2B, "FigS2B_protein_PCA",  width = 5, height = 4)
save_fig_pdf(pS2C, "FigS2C_metab_PCA",    width = 5, height = 4)

# Save coordinates for reproducibility
for (n in names(ord_results)) {
  save_fig_data(ord_results[[n]]$coords,
                paste0("FigS2_", n, "_ordination_coords.csv"))
}

# =====================================================================
# Fig S2D : PERMANOVA decomposition across covariates
# Robust version: prevents empty panel when some covariates fail
# =====================================================================
message("\n[FigS2D] PERMANOVA across covariates ...")

# Build metadata table robustly.
# Keep one row per company_id and avoid duplicated/ambiguous columns.
covar_tbl <- master %>%
  select(company_id, time_window) %>%
  left_join(
    clin %>%
      select(any_of(c("company_id", "age", "sex", "egfr_ckdepi",
                      "primary_disease"))) %>%
      distinct(company_id, .keep_all = TRUE),
    by = "company_id"
  )

# Add missing columns if any clinical field is absent.
if (!"age" %in% names(covar_tbl)) covar_tbl$age <- NA_real_
if (!"sex" %in% names(covar_tbl)) covar_tbl$sex <- NA_character_
if (!"egfr_ckdepi" %in% names(covar_tbl)) covar_tbl$egfr_ckdepi <- NA_real_
if (!"primary_disease" %in% names(covar_tbl)) covar_tbl$primary_disease <- NA_character_

covar_tbl <- covar_tbl %>%
  mutate(
    age = suppressWarnings(as.numeric(age)),
    egfr_ckdepi = suppressWarnings(as.numeric(egfr_ckdepi)),

    age_tertile = ifelse(is.na(age), NA_integer_, ntile(age, 3)),
    age_tertile = factor(age_tertile,
                         levels = c(1, 2, 3),
                         labels = c("Younger", "Middle", "Older")),

    egfr_tertile = ifelse(is.na(egfr_ckdepi), NA_integer_,
                          ntile(egfr_ckdepi, 3)),
    egfr_tertile = factor(egfr_tertile,
                          levels = c(1, 2, 3),
                          labels = c("Low eGFR", "Mid eGFR", "High eGFR")),

    etiology = case_when(
      is.na(primary_disease) ~ NA_character_,
      grepl("移植肾失功", primary_disease, fixed = TRUE) ~ "Failed allograft",
      grepl("乙肝", primary_disease, fixed = TRUE) ~ "HBV coinfection",
      TRUE ~ "ESRD other"
    ),
    etiology = factor(etiology),
    sex = factor(sex)
  )

# Robust one-covariate PERMANOVA helper.
# Returns a row even when the model is skipped or fails, so the CSV is informative.
permanova_one <- function(dist_mat, meta_tbl, covar_name, layer_name) {

  ids <- intersect(labels(dist_mat), meta_tbl$company_id)
  if (length(ids) < 8) {
    return(tibble(layer = layer_name, covariate = covar_name,
                  R2 = NA_real_, pseudo_F = NA_real_, p = NA_real_,
                  n = length(ids), status = "skipped_n_lt_8"))
  }

  meta_sub <- meta_tbl %>%
    filter(company_id %in% ids) %>%
    arrange(match(company_id, ids)) %>%
    mutate(covar = .data[[covar_name]]) %>%
    filter(!is.na(covar))

  if (nrow(meta_sub) < 8) {
    return(tibble(layer = layer_name, covariate = covar_name,
                  R2 = NA_real_, pseudo_F = NA_real_, p = NA_real_,
                  n = nrow(meta_sub), status = "skipped_nonmissing_n_lt_8"))
  }

  # PERMANOVA needs at least two covariate levels.
  covar_factor <- droplevels(as.factor(meta_sub$covar))
  if (nlevels(covar_factor) < 2) {
    return(tibble(layer = layer_name, covariate = covar_name,
                  R2 = NA_real_, pseudo_F = NA_real_, p = NA_real_,
                  n = nrow(meta_sub), status = "skipped_single_level"))
  }

  d_mat <- as.matrix(dist_mat)
  d_sub <- as.dist(d_mat[meta_sub$company_id, meta_sub$company_id])
  df_meta <- data.frame(covar = covar_factor)

  res <- tryCatch(
    vegan::adonis2(d_sub ~ covar,
                   data = df_meta,
                   permutations = 999,
                   by = "terms"),
    error = function(e) e
  )

  if (inherits(res, "error")) {
    return(tibble(layer = layer_name, covariate = covar_name,
                  R2 = NA_real_, pseudo_F = NA_real_, p = NA_real_,
                  n = nrow(meta_sub),
                  status = paste0("error: ", res$message)))
  }

  tibble(
    layer = layer_name,
    covariate = covar_name,
    R2 = as.numeric(res$R2[1]),
    pseudo_F = as.numeric(res$F[1]),
    p = as.numeric(res$`Pr(>F)`[1]),
    n = nrow(meta_sub),
    status = "ok"
  )
}

covariates_to_test <- c("time_window", "etiology", "egfr_tertile",
                        "age_tertile", "sex")

perm_df <- bind_rows(lapply(names(ord_results), function(layer_name) {
  bind_rows(lapply(covariates_to_test, function(cv_name) {
    permanova_one(
      dist_mat = ord_results[[layer_name]]$dist,
      meta_tbl = covar_tbl,
      covar_name = cv_name,
      layer_name = layer_name
    )
  }))
}))

save_fig_data(perm_df, "FigS2D_PERMANOVA_decomposition.csv")

message("FigS2D PERMANOVA rows: ", nrow(perm_df))
message("FigS2D successful models: ", sum(perm_df$status == "ok", na.rm = TRUE))

perm_plot <- perm_df %>%
  filter(status == "ok", !is.na(R2), !is.na(p)) %>%
  mutate(
    layer = factor(layer, levels = c("Genus", "Protein", "Metabolite")),
    covariate = factor(
      covariate,
      levels = c("time_window", "etiology", "egfr_tertile",
                 "age_tertile", "sex"),
      labels = c("Time window", "Etiology", "eGFR tertile",
                 "Age tertile", "Sex")
    ),
    p_label = ifelse(p < 0.001, "p<0.001", sprintf("p=%.3f", p))
  )

# Use explicit layer colors to avoid missing names in LAYER_COLORS.
figs2_layer_cols <- c(
  "Genus" = "#4C78A8",
  "Protein" = "#72B7B2",
  "Metabolite" = "#F2CF5B"
)

if (nrow(perm_plot) == 0) {

  pS2D <- ggplot() +
    annotate("text", x = 0, y = 0,
             label = "No valid PERMANOVA models after filtering.\nCheck FigS2D_PERMANOVA_decomposition.csv.",
             size = 3.2, color = "grey30") +
    labs(title = "D  PERMANOVA decomposition by covariate") +
    theme_void() +
    theme(plot.title = element_text(face = "bold", hjust = 0))

} else {

  pS2D <- ggplot(perm_plot,
                 aes(x = R2 * 100,
                     y = covariate,
                     fill = layer)) +
    geom_col(position = position_dodge(width = 0.72),
             width = 0.62,
             color = "grey25",
             linewidth = 0.18) +
    geom_text(aes(label = p_label),
              position = position_dodge(width = 0.72),
              hjust = -0.08,
              size = 2.0,
              color = "grey25") +
    scale_fill_manual(values = figs2_layer_cols, name = "Layer") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.25))) +
    labs(x = expression("PERMANOVA R"^2 * " (%)"),
         y = NULL,
         title = "D  PERMANOVA decomposition by covariate") +
    coord_cartesian(clip = "off") +
    theme_nature_pub(7) +
    theme(
      legend.position = "right",
      plot.margin = margin(5.5, 35, 5.5, 5.5)
    )
}

save_fig_pdf(pS2D, "FigS2D_PERMANOVA_decomposition",
             width = 6.5, height = 4)

# =====================================================================
# Combined Fig S2
# =====================================================================
message("\n[FigS2] Combined ...")

figS2 <- ((pS2A | pS2B | pS2C) /
          pS2D) +
  plot_layout(heights = c(1, 1)) +
  plot_annotation(tag_levels = list(c("A", "B", "C", "D"))) &
  theme(plot.tag = element_text(face = "bold", size = 11))

save_fig_pdf(figS2, "FigS2_extended_PCA_PERMANOVA",
             width = 14, height = 8)
message("\nFig S2 complete.\n")
