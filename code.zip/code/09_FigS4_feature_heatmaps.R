# =====================================================================
# 17_FigS4_feature_heatmaps.R
# Supplementary Figure S4 — Full per-feature Spearman heatmaps across
# all measured genera, KO-level protein modules, and HMDB Level 1 to 3
# metabolites, against Cr / CysC / eGFR.
# =====================================================================

source("R/setup.R")

master    <- read_csv(file.path(PROC_DIR, "sample_master_mapping.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
clin      <- read_csv(file.path(PROC_DIR, "clinical_processed.csv"),
                      show_col_types = FALSE) %>%
  mutate(time_window = factor(time_window, levels = TIME_LEVELS))
genus     <- readRDS(file.path(PROC_DIR, "metag_genus_relative.rds"))
metaprot  <- readRDS(file.path(PROC_DIR, "metaprot_abundance.rds"))
prot_anno <- readRDS(file.path(PROC_DIR, "metaprot_annotation.rds"))
prot_qc   <- read_csv(file.path(PROC_DIR, "metaprot_qc.csv"),
                      show_col_types = FALSE)
metab     <- readRDS(file.path(PROC_DIR, "metab_abundance.rds"))
metab_feat<- read_csv(file.path(PROC_DIR, "metab_features.csv"),
                      show_col_types = FALSE)

prot_pass <- prot_qc %>% filter(qc_status != "fail") %>% pull(company_id)

clin_lookup <- clin %>%
  select(company_id,
         Cr = cr_umol_L, CysC = cysC_mg_L, eGFR = egfr_ckdepi)

# =====================================================================
# Statistical helpers
# =====================================================================
spearman_test <- function(x, y) {
  ok <- complete.cases(x, y)
  if (sum(ok) < 8) return(c(rho = NA_real_, p = NA_real_, n = sum(ok)))
  rs <- suppressWarnings(cor.test(x[ok], y[ok], method = "spearman",
                                  exact = FALSE))
  c(rho = unname(rs$estimate), p = rs$p.value, n = sum(ok))
}

assoc_per_feature <- function(feat_mat, clin_lookup, n_cap = 60) {
  feat_long <- list()
  ids <- intersect(rownames(feat_mat), clin_lookup$company_id)
  cl_sub <- clin_lookup[match(ids, clin_lookup$company_id), ]
  for (f in colnames(feat_mat)) {
    x <- feat_mat[ids, f]
    for (idx in c("Cr","CysC","eGFR")) {
      st <- spearman_test(x, cl_sub[[idx]])
      feat_long[[length(feat_long)+1]] <- tibble(
        feature = f, clinical_index = idx,
        rho = st["rho"], p = st["p"], n = st["n"])
    }
  }
  out <- bind_rows(feat_long) %>%
    group_by(clinical_index) %>%
    mutate(q = p.adjust(p, method = "BH")) %>%
    ungroup()
  out
}

select_top_features <- function(assoc_df, n_cap) {
  # Keep features with the strongest signal anywhere across Cr/CysC/eGFR
  # then cap at n_cap to keep heatmap legible
  ranked <- assoc_df %>%
    group_by(feature) %>%
    summarise(max_abs_rho = max(abs(rho), na.rm = TRUE),
              best_q      = min(q,         na.rm = TRUE),
              .groups = "drop") %>%
    arrange(best_q, desc(max_abs_rho))
  head(ranked$feature, n_cap)
}

plot_feat_heatmap <- function(assoc_df, title) {
  assoc_df %>%
    mutate(clinical_index = factor(clinical_index,
                                    levels = c("Cr","CysC","eGFR")),
           star = case_when(
             !is.na(q) & q < 0.05 ~ "*",
             !is.na(q) & q < 0.10 ~ "·",
             TRUE                  ~ ""),
           feature = factor(feature,
                            levels = unique(feature))) %>%
    ggplot(aes(clinical_index, feature, fill = rho)) +
    geom_tile(color = "white", linewidth = 0.3) +
    geom_text(aes(label = star), size = 2.5, color = "grey15",
              vjust = 0.5) +
    scale_fill_gradient2(low = HEATMAP_LOW, mid = HEATMAP_MID,
                         high = HEATMAP_HIGH, midpoint = 0,
                         limits = c(-1, 1), name = "ρ") +
    scale_y_discrete(limits = rev) +
    labs(x = NULL, y = NULL, title = title) +
    theme_nature_pub(7) +
    theme(panel.grid = element_blank(),
          axis.line = element_blank(),
          axis.text.y = element_text(size = 5),
          axis.text.x = element_text(face = "bold"))
}

# =====================================================================
# Layer 1 : Per-genus (prevalence >= 20%, mean rel abund >= 1e-4)
# =====================================================================
message("\n[FigS4A] Per-genus heatmap ...")

genus_w <- genus %>%
  filter(rel_abund > 0) %>%
  pivot_wider(names_from = genus, values_from = rel_abund,
              values_fill = 0)
genus_m <- as.matrix(genus_w[, -1]); rownames(genus_m) <- genus_w$company_id
keep_g <- (colSums(genus_m > 0) >= 0.20 * nrow(genus_m)) &
          (colMeans(genus_m) >= 1e-4)
genus_m_keep <- log10(genus_m[, keep_g] + 1e-6)

genus_assoc <- assoc_per_feature(genus_m_keep, clin_lookup)
top_genera <- select_top_features(genus_assoc, n_cap = 50)
genus_top <- genus_assoc %>% filter(feature %in% top_genera) %>%
  mutate(feature = factor(feature, levels = rev(top_genera)))

save_fig_data(genus_assoc, "FigS4A_per_genus_full_association.csv")

pS4A <- plot_feat_heatmap(genus_top,
                          "A  Top 50 genera (* q<0.05, · q<0.10)")

save_fig_pdf(pS4A, "FigS4A_per_genus_heatmap",
             width = 4.5, height = 8.0)

# =====================================================================
# Layer 2 : Per-KO module (aggregate to KO level for legibility)
# =====================================================================
message("\n[FigS4B] Per-KO module heatmap ...")

ko_per_sample <- metaprot %>%
  filter(company_id %in% prot_pass) %>%
  inner_join(prot_anno %>% select(protein_id, KO_id) %>%
               filter(!is.na(KO_id), KO_id != ""),
             by = "protein_id") %>%
  group_by(company_id, KO_id) %>%
  summarise(abund = sum(abundance, na.rm = TRUE), .groups = "drop")

ko_w <- ko_per_sample %>%
  pivot_wider(names_from = KO_id, values_from = abund, values_fill = 0)
ko_m <- as.matrix(ko_w[, -1]); rownames(ko_m) <- ko_w$company_id

keep_ko <- colSums(ko_m > 0) >= 0.50 * nrow(ko_m)
ko_m_keep <- log2(ko_m[, keep_ko] + 1)

ko_assoc <- assoc_per_feature(ko_m_keep, clin_lookup)
top_ko <- select_top_features(ko_assoc, n_cap = 50)
ko_top <- ko_assoc %>% filter(feature %in% top_ko) %>%
  mutate(feature = factor(feature, levels = rev(top_ko)))

save_fig_data(ko_assoc, "FigS4B_per_KO_full_association.csv")

pS4B <- plot_feat_heatmap(ko_top,
                          "B  Top 50 KO modules (* q<0.05, · q<0.10)")
save_fig_pdf(pS4B, "FigS4B_per_KO_heatmap",
             width = 4.5, height = 8.0)

# =====================================================================
# Layer 3 : Per-metabolite (Level 1 + Level 2)
# =====================================================================
message("\n[FigS4C] Per-metabolite heatmap ...")

metab_l12 <- metab_feat %>%
  filter(Level %in% c("level1", "level2")) %>%
  pull(metabolite_id)

metab_w <- metab %>%
  filter(metabolite_id %in% metab_l12) %>%
  pivot_wider(names_from = metabolite_id, values_from = value,
              values_fill = NA)
metab_m <- as.matrix(metab_w[, -1]); rownames(metab_m) <- metab_w$company_id
metab_m[is.na(metab_m)] <- 0

keep_metab <- colMeans(metab_m > 0) >= 0.70
metab_m_keep <- log2(metab_m[, keep_metab] + 1)

# Rename feature labels with metabolite Name for readability
name_lookup <- metab_feat %>%
  select(metabolite_id, Name) %>%
  distinct(metabolite_id, .keep_all = TRUE)

metab_assoc <- assoc_per_feature(metab_m_keep, clin_lookup) %>%
  left_join(name_lookup, by = c("feature" = "metabolite_id")) %>%
  mutate(display = coalesce(Name, feature))

top_metab <- select_top_features(metab_assoc, n_cap = 50)
metab_top <- metab_assoc %>% filter(feature %in% top_metab) %>%
  mutate(display = factor(display, levels = rev(unique(display))))

save_fig_data(metab_assoc, "FigS4C_per_metabolite_full_association.csv")

pS4C <- ggplot(metab_top,
               aes(clinical_index %>% factor(levels = c("Cr","CysC","eGFR")),
                   display, fill = rho)) +
  geom_tile(color = "white", linewidth = 0.3) +
  geom_text(aes(label = ifelse(!is.na(q) & q < 0.05, "*",
                                ifelse(!is.na(q) & q < 0.10, "·", ""))),
            size = 2.5, color = "grey15", vjust = 0.5) +
  scale_fill_gradient2(low = HEATMAP_LOW, mid = HEATMAP_MID,
                       high = HEATMAP_HIGH, midpoint = 0,
                       limits = c(-1, 1), name = "ρ") +
  scale_y_discrete(limits = rev) +
  labs(x = NULL, y = NULL,
       title = "C  Top 50 metabolites (* q<0.05, · q<0.10)") +
  theme_nature_pub(7) +
  theme(panel.grid = element_blank(),
        axis.line = element_blank(),
        axis.text.y = element_text(size = 5),
        axis.text.x = element_text(face = "bold"))

save_fig_pdf(pS4C, "FigS4C_per_metabolite_heatmap",
             width = 6.0, height = 8.0)

# =====================================================================
# Combined Fig S4
# =====================================================================
message("\n[FigS4] Combined ...")

figS4 <- (pS4A | pS4B | pS4C) +
  plot_layout(guides = "collect") +
  plot_annotation(tag_levels = list(c("A", "B", "C"))) &
  theme(plot.tag = element_text(face = "bold", size = 11),
        legend.position = "right")

save_fig_pdf(figS4, "FigS4_per_feature_heatmaps",
             width = 16, height = 8.5)
message("\nFig S4 complete.\n")
